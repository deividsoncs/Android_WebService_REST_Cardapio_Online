package br.projetoandroid;

import java.util.ArrayList;
import java.util.List;

import br.cardapio.bean.Estabelecimento;
import br.cardapio.bean.Servicos;
import br.cardapio.listas.ServicosList;
import br.cardapio.requisicao.ServicoReq;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemClickListener;

public class ConsultaServicos extends MainActivity implements OnItemClickListener{
	private static final String CATEGORIA = "cardapio";
	private Spinner spinnerServicos;
	private long idServico=0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.consulta_servicos);
		
		//Identifica o Spinner no layout
		spinnerServicos = (Spinner) findViewById(R.id.spinnerServicos);
		List<Servicos> servicos = new ServicoReq().getListaServicos();
		
		//Cria um ArrayAdapter usando um padr�o de layout da classe R do android, passando o ArrayList nome dos servi�o
		ArrayAdapter<Servicos> arrayAdapter = new ArrayAdapter<Servicos>(this, android.R.layout.simple_spinner_item, servicos);
		spinnerServicos.setAdapter(arrayAdapter);
		
		//M�todo do Spinner para capturar o item selecionado
		spinnerServicos.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parent, View v, int posicao, long id) {
				//pega nome pela posi��o
				Servicos serv = (Servicos)parent.getSelectedItem();
				idServico = serv.getId();
				
			}
			@Override
			public void onNothingSelected(AdapterView<?> parent) {
 
			}
		});
		
		Button btListarEstabelecimentoCidade = (Button) findViewById(R.id.btListarEstabelecimentosCidade);
		btListarEstabelecimentoCidade.setOnClickListener(this); 
	}
	
	public void onClick(View v) {
		Intent it;
		switch (v.getId()){
		case R.id.btListarEstabelecimentosCidade:
			it = new Intent("LISTAGEM_ESTABELECIMENTO");
			//Seta o que ser� passado CIDADE e Reseta TODOS OUTROS!
			it.putExtra("BUSCA_POR_CIDADE", "");
			it.putExtra("BUSCA_POR_SERVICOS", idServico);
			startActivity(it);
		}
		
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		
	}
}
