package br.cardapio.requisicao;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

import br.cardapio.listas.AvaliacaoList;

public class AvaliacaoReq {

	
	public AvaliacaoList getListaPorIdEstabelecimento(long idEstabelecimento){
		
		AvaliacaoList avaliacaoList  = new AvaliacaoList();
		try{
	        URL url = new URL("http://localhost:8080/cardapio.online/rest/recursos/busca_avaliacao_por_estabelecimento/" + idEstabelecimento);
	        HttpURLConnection con = (HttpURLConnection) url.openConnection();
	        
	        if (con.getResponseCode() != 200) {
	                throw new RuntimeException("HTTP error code : "+ con.getResponseCode());
	        }
	        
	        //C�digo
	
	        System.out.println("------  Dados da Avalia��o  -------- \n");
	        System.out.println(avaliacaoList.toString());
	        con.disconnect();
	
	    } catch (IOException e) {
	        e.printStackTrace();
		}
		return avaliacaoList;
	}
	
}
