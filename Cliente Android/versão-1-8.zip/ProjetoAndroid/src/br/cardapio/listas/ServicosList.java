package br.cardapio.listas;

import java.util.ArrayList;
import java.util.List;

import br.cardapio.bean.Servicos;


public class ServicosList {

    private List <Servicos> lista =  null;

    public ServicosList(){
        lista = new ArrayList<Servicos>();
    }

    public void add(Servicos novo){
        lista.add(novo);
    }
    
    public boolean isEmpty(){
    	return lista.isEmpty();
    }
    
	public String toString() {
		String str = " ";
		for (Servicos objeto : lista){
			str += objeto.toString() + " \n";
		}
		return str;
	}

    public List<Servicos> getLista() {
        return lista;
    }

    public void setLista(List<Servicos> lista) {
        this.lista = lista;
    }
        
        
}
