package br.projetoandroid;

import java.io.Serializable;
import java.util.ArrayList;

import br.cardapio.bean.Endereco;
import br.cardapio.bean.Estabelecimento;
import br.cardapio.requisicao.EnderecoReq;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

@SuppressWarnings("serial")
public class EstabelecimentoActivity extends Activity implements Serializable{
	
	@SuppressWarnings("unchecked")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.estabelecimento_layout);
		
		TextView tvNomeFantasia = (TextView) findViewById(R.id.tvNomeFantasia);
		TextView tvEmail = (TextView) findViewById(R.id.tvEmail);
		TextView tvTelefone = (TextView) findViewById(R.id.tvTelefone);
		TextView tvGostaram = (TextView) findViewById(R.id.tvGostaram);
		TextView tvEndereco = (TextView)findViewById(R.id.tvEndereco);
		
		//Recebe a opera��o e o par�metro de outra activity
		ArrayList<Estabelecimento> listaEstabelecimento = new ArrayList<Estabelecimento>();
		Estabelecimento estabelecimento = new Estabelecimento();
		Intent intent = getIntent();
		Bundle params = intent.getExtras();  
		if(params!=null){   
			listaEstabelecimento = (ArrayList<Estabelecimento>) params.getSerializable("lista_estabelecimento");
			estabelecimento = listaEstabelecimento.get(0);
			
			tvNomeFantasia.setText(estabelecimento.getNomeFantasia());
			tvEmail.setText(estabelecimento.getEmail());
			tvTelefone.setText("Telefone: " + estabelecimento.getTelefone());
			tvGostaram.setText("Likes: " + Integer.valueOf(estabelecimento.getGostaram()));
			Endereco endereco = new EnderecoReq().getEnderecoPorIdEstabelecimento(estabelecimento.getId());
			tvEndereco.setText(" End: " + endereco.getLogradouro() + ", " + endereco.getBairro() + ", " + endereco.getCidade());
		}	
	}
}
