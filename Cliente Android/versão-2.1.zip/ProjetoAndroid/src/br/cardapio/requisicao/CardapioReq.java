package br.cardapio.requisicao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import br.cardapio.bean.Cardapio;


public class CardapioReq {
	
	public Cardapio getCardapioPorIdEstabelecimento(long idEstabelecimento){
		Cardapio cardapio  = new Cardapio();
		try{
	        URL url = new URL("http://localhost:8080/cardapio.online/rest/recursos/busca_cardapio_por_Estabelecimento/" + idEstabelecimento);
	        HttpURLConnection con = (HttpURLConnection) url.openConnection();
	        
	        if (con.getResponseCode() != 200) {
	                throw new RuntimeException("HTTP error code : "+ con.getResponseCode());
	        }
	        BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));
	        
	        //C�digo
	        
	        
	        con.disconnect();
	
	    } catch (IOException e) {
	        e.printStackTrace();
	    } 
		return cardapio;
	}
	
}
