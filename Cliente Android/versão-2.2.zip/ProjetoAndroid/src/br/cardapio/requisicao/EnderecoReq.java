package br.cardapio.requisicao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.google.gson.Gson;

import android.util.Log;
import br.cardapio.bean.Endereco;

public class EnderecoReq {
	
	public Endereco getEnderecoPorIdEstabelecimento(long idEstabelecimento){
		Endereco endereco  = new Endereco();
		try{
	        URL url = new URL("http://"+ Conexao.getSERVIDOR() +"/cardapio.online/rest/recursos/busca_endereco_por_estabelecimento_android/" + idEstabelecimento);
	        HttpURLConnection con = (HttpURLConnection) url.openConnection();
	        
	        if (con.getResponseCode() != 200) {
	                throw new RuntimeException("HTTP error code : "+ con.getResponseCode());
	        }
	        
	        BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));
	        endereco = new Gson().fromJson(br, Endereco.class);
	        Log.i("TESTE", "retorno Lista   " + endereco.toString() );  
	
	        System.out.println("------  Dados do Endere�o  -------- \n");
	        System.out.println(endereco.toString());
	        con.disconnect();
	
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
		return endereco;
	}
}
