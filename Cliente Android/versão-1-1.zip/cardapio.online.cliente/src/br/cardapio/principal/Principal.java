package br.cardapio.principal;

import br.cardapio.bean.UsuarioEstabelecimento;
import br.cardapio.requisicao.EnderecoReq;
import br.cardapio.requisicao.UsuarioEstabelecimentoReq;

public class Principal {

	public static void main(String[] args) {
		
		new UsuarioEstabelecimentoReq().getListaUsuarioEstabelecimentoPorNome("Dei");
		
		new EnderecoReq().getEnderecoPorIdEstabelecimento(4);
		
		UsuarioEstabelecimento usuarioEstabelecimento = new UsuarioEstabelecimento("Helio", "baixinho", "brasil10");
		new UsuarioEstabelecimentoReq().adiciona(usuarioEstabelecimento);
	}

}
