package br.cardapio.listas;

import java.util.ArrayList;
import java.util.List;

import br.cardapio.bean.SecaoCardapio;

public class SecaoCardapioList {
    private List <SecaoCardapio> lista =  null;

    public SecaoCardapioList(){
        lista = new ArrayList<SecaoCardapio>();
    }

    public void add(SecaoCardapio novo){
        lista.add(novo);
    }
    
    public boolean isEmpty(){
    	return lista.isEmpty();
    }
    
	public String toString() {
		String str = " ";
		for (SecaoCardapio objeto : lista){
			str += objeto.toString() + " \n";
		}
		return str;
	}

    public List<SecaoCardapio> getLista() {
        return lista;
    }

    public void setLista(List<SecaoCardapio> lista) {
        this.lista = lista;
    }
}
