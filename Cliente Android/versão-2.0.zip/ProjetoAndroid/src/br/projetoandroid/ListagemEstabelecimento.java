package br.projetoandroid;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import br.cardapio.bean.Estabelecimento;
import br.cardapio.listas.EstabelecimentoList;
import br.cardapio.requisicao.EstabelecimentoReq;

public class ListagemEstabelecimento extends MainActivity{

	private static final String CATEGORIA = "cardapio";
	private ListView lv;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.listagem_estabelecimento);
		
		//Recebe a opera��o e o par�metro de outra activity
		Intent intent = getIntent();		
		String cidade = intent.getStringExtra("BUSCA_POR_CIDADE");
		long idServico = intent.getLongExtra("BUSCA_POR_SERVICOS", 0);
		//Preenche Lista

		if (!cidade.equals("")){
			List<Estabelecimento> l = getListaEstabelecimentoPorCidade(cidade);
			ListaEstabelecimentoAdapter estabelecimentosAdapter = new ListaEstabelecimentoAdapter(this,  l);
			lv = (ListView) findViewById(R.id.listViewEstabelecimentos);
		    lv.setAdapter((ListAdapter) estabelecimentosAdapter);		
		}
			
		if (!(idServico==0L)){
			List<Estabelecimento> l = getListaEstabelecimentoPorServicos(idServico);
			ListaEstabelecimentoAdapter estabelecimentosAdapter = new ListaEstabelecimentoAdapter(this,  l);
			lv = (ListView) findViewById(R.id.listViewEstabelecimentos);
		    lv.setAdapter((ListAdapter) estabelecimentosAdapter);		
		}
		
		
	}
	
	//M�todo que recebe a cidade e procura por estabelecimento desta e retorna em formato de Lista
	private List<Estabelecimento> getListaEstabelecimentoPorCidade(String cidade) {
        List<String> l = new ArrayList<String>();       
        EstabelecimentoList listaEstabelecimento = new EstabelecimentoList();
        listaEstabelecimento.setLista(new EstabelecimentoReq().getListaEstabelecimentoPorCidade(cidade).getLista());
       
        Toast.makeText(this, "Resultado!", Toast.LENGTH_SHORT).show();
        Log.i(CATEGORIA, "retorno Lista" + l.toString());
       
        return listaEstabelecimento.getLista();
    }
	
	//M�todo que recebe o ID de servicos e procura por estabelecimento desta e retorna em formato de Lista
	private List<Estabelecimento> getListaEstabelecimentoPorServicos(long idServico) {
        List<String> l = new ArrayList<String>();       
        EstabelecimentoList listaEstabelecimento = new EstabelecimentoList();
        listaEstabelecimento.setLista(new EstabelecimentoReq().getEstebelecimentoPorIdServico(idServico).getLista());
       
        Toast.makeText(this, "Resultado!", Toast.LENGTH_SHORT).show();
        Log.i(CATEGORIA, "retorno Lista" + l.toString());
       
        return listaEstabelecimento.getLista();
    }
}
