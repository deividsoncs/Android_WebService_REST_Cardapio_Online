package br.projetoandroid;
import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import br.cardapio.bean.Endereco;
import br.cardapio.bean.Estabelecimento;
import br.cardapio.requisicao.EnderecoReq;
public class ListaEstabelecimentoAdapter extends ArrayAdapter<Estabelecimento>{
	private Context context;
    private List<Estabelecimento> estabelecimentos = null;
    
   
    public ListaEstabelecimentoAdapter(Context context,  List<Estabelecimento> estabelecimentos) {
        super(context,0, estabelecimentos);
        this.estabelecimentos = estabelecimentos;
        this.context = context;
    }
    
    @Override
    public View getView(int position, View view, ViewGroup parent) {
        Estabelecimento estabelecimento = estabelecimentos.get(position);
         
        if(view == null)
            view = LayoutInflater.from(context).inflate(R.layout.item_estabelecimento_lista, null);
 
        ImageView imageViewEstabelecimento = (ImageView) view.findViewById(R.id.image_view_estabelecimento);
        //imageViewEstabelecimento.setImageResource(null);
         
        TextView textViewNomeFantasia = (TextView) view.findViewById(R.id.text_view_nome_fantasia);
        textViewNomeFantasia.setText(estabelecimento.getNomeFantasia());
         
        TextView textViewSubTitulto = (TextView)view.findViewById(R.id.text_view_endereco);
        Endereco endereco = new EnderecoReq().getEnderecoPorIdEstabelecimento(estabelecimento.getId());
        
        String textoSubTitulto= "Like: " +  String.valueOf(estabelecimento.getGostaram()) + " End: " + endereco.getLogradouro() + ", " + endereco.getBairro() + ", " + endereco.getCidade();
        textViewSubTitulto.setText(textoSubTitulto);
 
        return view;
    }
}
