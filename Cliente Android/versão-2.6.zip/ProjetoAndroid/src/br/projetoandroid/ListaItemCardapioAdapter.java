package br.projetoandroid;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import br.cardapio.bean.ItemCardapio;

public class ListaItemCardapioAdapter extends ArrayAdapter<ItemCardapio>{
	private Context context;
    private List<ItemCardapio> listaItemCardapio = null;
    
   
    public ListaItemCardapioAdapter(Context context,  List<ItemCardapio> listaItemCardapio) {
        super(context,0, listaItemCardapio);
        this.listaItemCardapio = listaItemCardapio;
        this.context = context;
    }
    
    @Override
    public View getView(int position, View view, ViewGroup parent) {
        ItemCardapio itemCardapio = listaItemCardapio.get(position);
         
        if(view == null)
            view = LayoutInflater.from(context).inflate(R.layout.item_cardapio_lista, null);
        
        ImageView imageViewEstabelecimento = (ImageView) view.findViewById(R.id.image_item_icon);
        imageViewEstabelecimento.setImageResource(R.drawable.icon_item_produto_standart);
         
        TextView textViewNomeItem = (TextView) view.findViewById(R.id.tvNome_item);
        textViewNomeItem.setText(itemCardapio.getNomeItem());
         
        TextView textViewDescricao = (TextView)view.findViewById(R.id.tvDescricao_item);
        textViewDescricao.setText(itemCardapio.getDescricao());
        
        TextView textViewPreco = (TextView)view.findViewById(R.id.tvPreco_item);
        textViewPreco.setText(Double.toString(itemCardapio.getPreco()));
        
        return view;
    }
}
