package br.projetoandroid;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import br.cardapio.bean.Avaliacao;

public class ListaAvaliacaoAdapter  extends ArrayAdapter<Avaliacao> {
	private Context context;
    private List<Avaliacao> listaAvaliacao = null;
    
   
    public ListaAvaliacaoAdapter(Context context,  List<Avaliacao> listaAvaliacao) {
        super(context,0, listaAvaliacao);
        this.listaAvaliacao = listaAvaliacao;
        this.context = context;
    }
    
    @Override
    public View getView(int position, View view, ViewGroup parent) {
        Avaliacao avaliacao = listaAvaliacao.get(position);
         
        if(view == null)
            view = LayoutInflater.from(context).inflate(R.layout.item_avaliacao_lista, null);
 
        ImageView imageViewAvaliacao = (ImageView) view.findViewById(R.id.image_view_avaliacao);
        if (avaliacao.getPositivo()==1)
        	imageViewAvaliacao.setImageResource(R.drawable.bola_verde);
        else
        	imageViewAvaliacao.setImageResource(R.drawable.bola_vermelha);
        
        TextView tvDescricaoAvaliacao = (TextView) view.findViewById(R.id.tvDescricao_avaliacao);
        String textoSubTitulto= "Relato: " +  String.valueOf(avaliacao.getRelato());
        tvDescricaoAvaliacao.setText(textoSubTitulto);

        return view;
    }
}
