package br.cardapio.requisicao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import br.cardapio.bean.Cardapio;


public class CardapioReq {
	
	public Cardapio getCardapioPorIdEstabelecimento(long idEstabelecimento){
		Cardapio cardapio  = new Cardapio();
		try{
	        URL url = new URL("http://"+Conexao.getSERVIDOR()+"/cardapio.online/rest/recursos/busca_cardapio_por_estabelecimento_android/" + idEstabelecimento);
	        HttpURLConnection con = (HttpURLConnection) url.openConnection();
	        
	        if (con.getResponseCode() != 200) {
	                throw new RuntimeException("HTTP error code : "+ con.getResponseCode());
	        }
	        BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));
	        
	        GsonBuilder builder = new GsonBuilder();
	        builder.setDateFormat("dd/MM/yyyy");
	        Gson gson = builder.create();
	        cardapio = gson.fromJson(br, Cardapio.class);
	        
	        //Gson gson = WbJson.getGson();
	        //cardapio = gson.fromJson(br, Cardapio.class);
	        
	        //cardapio = new Gson().fromJson(br, Cardapio.class);
	        con.disconnect();
	    } catch (IOException e) {
	        e.printStackTrace();
	    } 
		return cardapio;
	}
}
