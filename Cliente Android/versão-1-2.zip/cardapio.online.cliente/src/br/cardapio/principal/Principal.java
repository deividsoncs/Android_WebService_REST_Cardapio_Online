package br.cardapio.principal;

import br.cardapio.bean.Estabelecimento;
import br.cardapio.bean.UsuarioEstabelecimento;
import br.cardapio.requisicao.EnderecoReq;
import br.cardapio.requisicao.EstabelecimentoReq;
import br.cardapio.requisicao.UsuarioEstabelecimentoReq;

public class Principal {

	public static void main(String[] args) {
		
		/**
		 * 
		USUARIOS:
		____________________________________________________________________________________________________________
		//Teste retornar lista de usuarios buscando por nomes OK
		new UsuarioEstabelecimentoReq().getListaUsuarioEstabelecimentoPorNome("Dei");
		
		new EnderecoReq().getEnderecoPorIdEstabelecimento(4);
		
		//UsuarioEstabelecimento usuarioEstabelecimento = new UsuarioEstabelecimento("Helio", "baixinho", "brasil10");
		//new UsuarioEstabelecimentoReq().adiciona(usuarioEstabelecimento);
		
		//Teste autentica��o OK
		UsuarioEstabelecimento usuarioEstabelecimento = new UsuarioEstabelecimento(0 ,"Helio", "baixinho", "brasil10");
		new UsuarioEstabelecimentoReq().autentica(usuarioEstabelecimento);
		
		//Teste atera��o OK
		UsuarioEstabelecimento usuarioTesteAltera = new UsuarioEstabelecimento(4 ,"Sergio Cardoso", "seginhoborlote", "chile10");
		new UsuarioEstabelecimentoReq().altera(usuarioTesteAltera);
		
		//Teste remo��o: OK
		new UsuarioEstabelecimentoReq().remove(4);
		
		//Teste Listar Todos usuarios OK
		new UsuarioEstabelecimentoReq().getListaUsuarioEstabelecimento();
		
		
		ESTABELECIMENTOS:
		____________________________________________________________________________________________________________
				
		//Teste Listar todos Estabelecimentos OK
		new EstabelecimentoReq().getListaEstabelecimentos();
		
		//Teste Listar todos Estabelecimentos Por Promo��o OK
		new EstabelecimentoReq().getListaEstabelecimentoPorPromocao();
		
		// Teste de Retornar a lista dos Estabelecimentos passando o Nome do Estabelecimento OK
		new EstabelecimentoReq().getListaEstabelecimentoPorNome("Belo");
		
		//> Retornar a lista dos Estabelecimentos passando a Cidade. OK
		new EstabelecimentoReq().getListaEstabelecimentoPorCidade("Vitoria");

		//> Retornar a lista dos Estabelecimentos passando a Cidade. OK
		new EstabelecimentoReq().getListaEstabelecimentoPorCidade("1");
		
		//> Retornar a lista dos Estabelecimentos passando a ID do Servi�os selecionado, ex.: Todos estabelecimento que possuem "m�sica ao vivo" OK
		new EstabelecimentoReq().getEstebelecimentoPorIdServico(2);

		// Lista todos Estabelecimentos pelos id do TipoEstabelecimento passado! Ex.: Lista de Estabelecimentos que s�o churrascarias. OK
		new EstabelecimentoReq().getEstebelecimentoPorIdTipo(5);
		
		//Teste Insere um novo Estabelecimento OK
		Estabelecimento estabelecimento = new Estabelecimento(1, "Betel Cormercio S/A", "Topa Tudo 100", "33369990", "betel@mg.com", "//1/2/logo.jpeg", 100);
		new EstabelecimentoReq().adiciona(estabelecimento);
		
		*/
		
		
		

	}

}
