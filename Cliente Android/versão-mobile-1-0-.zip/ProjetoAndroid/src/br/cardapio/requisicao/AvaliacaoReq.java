package br.cardapio.requisicao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import android.util.Log;
import br.cardapio.bean.Avaliacao;
import br.cardapio.listas.AvaliacaoList;

import com.google.gson.Gson;
public class AvaliacaoReq {

	public String adiciona (Avaliacao avaliacao){
		String output = "";	
		try{	
			Writer writer = new StringWriter();
			String strJson = new Gson().toJson(avaliacao);
			writer.write(strJson);
			
			URL url = new URL("http://"+ Conexao.getSERVIDOR()+"/cardapio.online/rest/recursos/novo_avaliacao_android");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			String input = writer.toString();
			OutputStream os = conn.getOutputStream();
			os.write(input.getBytes());
			os.flush();
			
			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Erro : HTTP c�digo de erro: " + conn.getResponseCode());
			}
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			
			while ((output = br.readLine()) != null) {
				System.out.println(output);
	            break;
			}
			conn.disconnect();

		} catch (IOException e) {
	        e.printStackTrace();
		}
		
		return output;
	}
	
	public List<Avaliacao> getListaPorIdEstabelecimento(long idEstabelecimento){
		
		AvaliacaoList avaliacaoList  = new AvaliacaoList();
		avaliacaoList.setLista(null);
		try{
	        URL url = new URL("http://"+ Conexao.getSERVIDOR() +"/cardapio.online/rest/recursos/busca_avaliacao_por_estabelecimento_android/" + idEstabelecimento);
	        HttpURLConnection con = (HttpURLConnection) url.openConnection();
	        
	        if (con.getResponseCode() != 200) {
	                throw new RuntimeException("HTTP error code : "+ con.getResponseCode());
	        }
	        BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));
	        avaliacaoList  = new Gson().fromJson(br, AvaliacaoList.class);
	        
	        if (avaliacaoList.getLista() == null){
	        
	        }
	     	Log.i("AplicacaoReq", "getListaPorIdEstabelecimento==[  " + avaliacaoList.toString() + "]"); 
	        con.disconnect();
	        con.disconnect();
	
	    } catch (IOException e) {
	        e.printStackTrace();
		}
		return avaliacaoList.getLista();
	}
	
}
