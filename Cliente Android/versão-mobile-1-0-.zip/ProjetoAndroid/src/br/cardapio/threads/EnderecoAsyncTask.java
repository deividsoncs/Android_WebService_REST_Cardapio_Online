package br.cardapio.threads;

import android.os.AsyncTask;
import android.util.Log;
import br.cardapio.bean.Endereco;
import br.cardapio.bean.Estabelecimento;
import br.cardapio.requisicao.EnderecoReq;

public class EnderecoAsyncTask extends AsyncTask<Estabelecimento, Object, Endereco> {

    public EnderecoAsyncTask() {
    }

    public Endereco doInBackground(Estabelecimento...estabelecimento){
    	Log.i("EnderecoAsyncTask", "idEstabelecimento  =" + estabelecimento[0].getId());
    	Endereco endereco = new Endereco();  
        endereco = new EnderecoReq().getEnderecoPorIdEstabelecimento(estabelecimento[0].getId());
        Log.i("EnderecoAsyncTask", "Endereco =" + endereco.toString());
        return endereco;
    }

    public void onPostExecute(Endereco endereco) {
    	//TextView textViewSubTitulto = (TextView) activity.findViewById(R.id.text_view_endereco);
    	//String textoSubTitulto= "Like: " +  String.valueOf(estabelecimento.getGostaram()) + " End: " + endereco.getLogradouro() + ", " + endereco.getBairro() + ", " + endereco.getCidade();
    	//textViewSubTitulto.setText(textoSubTitulto);
    }
}
