package br.cardapio.threads;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.AsyncTask;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import br.cardapio.bean.Servicos;
import br.cardapio.requisicao.ServicoReq;
import br.projetoandroid.R;

public class ConsultaServicosAsyncTask extends AsyncTask<Void, Object, List<Servicos>> {
	private Activity activity;
   
    public ConsultaServicosAsyncTask(Activity activity) {
        this.activity = activity;
    }
    
	public List<Servicos> doInBackground(Void... params){
    	List<Servicos> listaServicos = new ArrayList<Servicos>();
    	listaServicos = new ServicoReq().getListaServicos();
    	
        return listaServicos;

    }

    public void onPostExecute(List<Servicos> l) {
    	Spinner spinnerServicos = (Spinner) activity.findViewById(R.id.spinnerServicos);
		ArrayAdapter<Servicos> servicoAdapter = new ArrayAdapter<Servicos>(activity, android.R.layout.simple_spinner_item, l);  
		spinnerServicos.setAdapter(servicoAdapter); 
    }
}