package br.cardapio.bean;

public class TesteSerializer {
	
}
