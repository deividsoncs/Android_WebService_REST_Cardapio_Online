package br.projetoandroid;

import java.io.Serializable;
import java.util.ArrayList;

import br.cardapio.bean.Endereco;
import br.cardapio.bean.Estabelecimento;
import br.cardapio.requisicao.EnderecoReq;
import br.cardapio.requisicao.EstabelecimentoReq;
import android.app.Activity;
import android.util.Log;
import android.view.View.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

@SuppressWarnings("serial")
public class EstabelecimentoActivity extends Activity implements Serializable, OnClickListener{
	
	private ArrayList<Estabelecimento> listaEstabelecimento = new ArrayList<Estabelecimento>();
	private Estabelecimento estabelecimento = new Estabelecimento();
	
	@SuppressWarnings("unchecked")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.estabelecimento_layout);
		
		TextView tvNomeFantasia = (TextView) findViewById(R.id.tvNomeFantasia);
		TextView tvEmail = (TextView) findViewById(R.id.tvEmail);
		TextView tvTelefone = (TextView) findViewById(R.id.tvTelefone);
		TextView tvGostaram = (TextView) findViewById(R.id.tvGostaram);
		TextView tvEndereco = (TextView)findViewById(R.id.tvEndereco);
		
		//Recebe a opera��o e o par�metro de outra activity

		Intent intent = getIntent();
		Bundle params = intent.getExtras();  
		if(params!=null){   
			listaEstabelecimento = (ArrayList<Estabelecimento>) params.getSerializable("lista_estabelecimento");
			estabelecimento = listaEstabelecimento.get(0);
			
			tvNomeFantasia.setText(estabelecimento.getNomeFantasia());
			tvEmail.setText(estabelecimento.getEmail());
			tvTelefone.setText("Telefone: " + estabelecimento.getTelefone());
			tvGostaram.setText("Likes: " + Integer.valueOf(estabelecimento.getGostaram()));
			Endereco endereco = new EnderecoReq().getEnderecoPorIdEstabelecimento(estabelecimento.getId());
			tvEndereco.setText(" End: " + endereco.getLogradouro() + ", " + endereco.getBairro() + ", " + endereco.getCidade());
		}	
		
		ImageButton imageBtLike = (ImageButton) findViewById(R.id.imageBtLike);
		imageBtLike.setOnClickListener(this);
		
		ImageButton imageBtAvaliacao = (ImageButton) findViewById(R.id.imageBtAvaliacao);
		imageBtAvaliacao.setOnClickListener(this);
		
		ImageButton imageBtCardapio = (ImageButton) findViewById(R.id.imageBtCardapio);
		imageBtCardapio.setOnClickListener(this);
	}
	
	public void onClick(View v) {
		Intent it;
		switch (v.getId()){
		case R.id.imageBtLike:
			estabelecimento.setGostaram(estabelecimento.getGostaram() + 1);
			//Incrementa Gostaram no BANCO e mostra Toast na tela!
			Toast.makeText(this, new EstabelecimentoReq().altera(estabelecimento) , Toast.LENGTH_SHORT).show();
			//Atualiza a View
			TextView tvGostaram = (TextView) findViewById(R.id.tvGostaram);
			tvGostaram.setText("Likes: " + Integer.valueOf(estabelecimento.getGostaram()));
			break;
		case R.id.imageBtAvaliacao:
			it = new Intent(getApplicationContext(), AvalicaoActivity.class);
			Log.i("EstabelecimentoActivity", "IdEstabelecimento= " + Long.toString(estabelecimento.getId()) );
			it.putExtra("idEstabelecimento", estabelecimento.getId());
			startActivity(it);
			break;
		case R.id.imageBtCardapio:
			it = new Intent(getApplicationContext(), CardapioActivity.class);
			Log.i("EstabelecimentoActivity", "IdEstabelecimento= " + Long.toString(estabelecimento.getId()) );
			it.putExtra("idEstabelecimento", estabelecimento.getId());
			startActivity(it);
			break;
		}
		
	}
}
