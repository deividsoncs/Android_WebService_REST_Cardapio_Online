package br.projetoandroid;

import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import br.cardapio.bean.TipoEstabelecimento;
import br.cardapio.requisicao.TipoEstabelecimentoReq;

public class ConsultaTipoActivity extends Activity implements OnItemClickListener{
	//private static final String CATEGORIA = "cardapio";
	private Spinner spinnerTipos;
	private long idTipo=0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.consulta_tipos_layout);
		
		List<TipoEstabelecimento> l = new TipoEstabelecimentoReq().getListaTipoEstabelecimento();

		spinnerTipos = (Spinner) findViewById(R.id.spinnerTipos);
		ArrayAdapter<TipoEstabelecimento> servicoAdapter = new ArrayAdapter<TipoEstabelecimento>(this, android.R.layout.simple_spinner_item, l);  
		spinnerTipos.setAdapter(servicoAdapter); 
		spinnerTipos.setPrompt("Selecione um Tipo");
		spinnerTipos.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parent, View v, int posicao, long id) {
				//pega nome pela posi��o			
				TipoEstabelecimento tipo = (TipoEstabelecimento)parent.getSelectedItem();
				idTipo = tipo.getId();
				Log.i("ConsultaTipoActivity:", "idTipo="+Long.toString(idTipo));
			}
			@Override
			public void onNothingSelected(AdapterView<?> parent) {
 
			}
		});
	    
		getListenerButtonListaEstabelecimento();
	}
	
	public void getListenerButtonListaEstabelecimento(){
		Button btListarEstabelecimentosTipo = (Button) findViewById(R.id.btListarEstabelecimentosTipo);
		btListarEstabelecimentosTipo.setOnClickListener(new OnClickListener() { 
		@Override
		public void onClick(View v) {
			Intent it;
			switch (v.getId()){
			case R.id.btListarEstabelecimentosTipo:
				it = new Intent("LISTAGEM_ESTABELECIMENTO");
				//Seta o que ser� passado CIDADE e Reseta TODOS OUTROS!
				it.putExtra("BUSCA_POR_CIDADE", "");
				it.putExtra("BUSCA_POR_SERVICOS", 0);
				it.putExtra("BUSCA_POR_TIPO", idTipo);
				it.putExtra("BUSCA_POR_PROMOCAO", false);
				startActivity(it);
			}		
		}
	});
	}
	

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		
	}
}
