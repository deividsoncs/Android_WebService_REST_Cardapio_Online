package br.projetoandroid;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import br.cardapio.bean.Avaliacao;
import br.cardapio.requisicao.AvaliacaoReq;

public class AvalicaoActivity extends Activity implements android.view.View.OnClickListener{
	private ListView lv;
	private RadioGroup rdgAvaliacao;
	private RadioButton rdPositivo;
	private RadioButton rdNegativo;
	private Button btEnviarAvaliacao;
	private EditText edRelato;
	private int isPositivo = 0;
	private Avaliacao avaliacao = new Avaliacao();
	private long idEstabelecimento=0;
	private String strRelato="";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.avaliacao);
		
		//Recebe a opera��o e o par�metro de outra activity
		Bundle bundle = getIntent().getExtras();		
		idEstabelecimento = bundle.getLong("idEstabelecimento");
		
		Log.i("AvalicaoActivity", "idEstabelecimento = " + Long.toString(idEstabelecimento));
		if (idEstabelecimento!=0){
			List<Avaliacao> l = new AvaliacaoReq().getListaPorIdEstabelecimento(idEstabelecimento);
			ListaAvaliacaoAdapter avaliacaoAdapter = new ListaAvaliacaoAdapter(this,  l);
			lv = (ListView) findViewById(R.id.listViewAvaliacao);
		    lv.setAdapter((ListAdapter) avaliacaoAdapter);		
		}else{
			List<Avaliacao> l = new ArrayList<Avaliacao>();
			ListaAvaliacaoAdapter avaliacaoAdapter = new ListaAvaliacaoAdapter(this,  l);
			lv = (ListView) findViewById(R.id.listViewAvaliacao);
		    lv.setAdapter((ListAdapter) avaliacaoAdapter);	
		    Toast.makeText(this, "Esse Estabelecimento ainda n�o foi avaliado, seja o primeiro!", Toast.LENGTH_SHORT).show();
		}

		btEnviarAvaliacao = (Button) findViewById(R.id.btEnviarAvaliacao);
		btEnviarAvaliacao.setOnClickListener(this);
		
	}
	@Override
	public void onClick(View v) {
		if (v.getId() == R.id.btEnviarAvaliacao){
			
			rdgAvaliacao = (RadioGroup) findViewById(R.id.rdgAvaliacao);
			edRelato = (EditText) findViewById(R.id.edRelato); 
			strRelato = edRelato.getText().toString();
			Log.i("AvaliacaoActivity", edRelato.getText().toString());
			switch (rdgAvaliacao.getCheckedRadioButtonId()) {
		    case R.id.rdPositivo:
		        Toast.makeText(AvalicaoActivity.this, "Obrigado pela prefer�ncia!", Toast.LENGTH_SHORT).show();
		        isPositivo = 1;
		        break;
		    case R.id.rdNegativo:
		        Toast.makeText(AvalicaoActivity.this, "Tentaremos melhorar nossos servi�os! Obrigado.", Toast.LENGTH_SHORT).show();
		        isPositivo= 0;
		        break;
			}
			
			avaliacao.setRelato(strRelato);
			avaliacao.setPositivo(isPositivo);
			avaliacao.setIdEstabelecimento(idEstabelecimento);
			//Envia requisi��o para WebService!
			Toast.makeText(AvalicaoActivity.this, new AvaliacaoReq().adiciona(avaliacao), Toast.LENGTH_SHORT).show();
		}
	}	
}
