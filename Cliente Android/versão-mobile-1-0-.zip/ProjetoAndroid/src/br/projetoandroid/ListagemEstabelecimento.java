package br.projetoandroid;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import br.cardapio.bean.Estabelecimento;
import br.cardapio.threads.ListagemEstabelecimentoAsyncTask;

public class ListagemEstabelecimento extends MainActivity implements OnItemClickListener{
	private ListView lv;
	
	@SuppressWarnings("unchecked")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.listagem_estabelecimento);
		
		//Recebe a opera��o e o par�metro de outra activity
		Bundle bundle = getIntent().getExtras();
		String cidade = bundle.getString("BUSCA_POR_CIDADE");
		long idServico = bundle.getLong("BUSCA_POR_SERVICOS");
		long idTipo = bundle.getLong("BUSCA_POR_TIPO");
		boolean buscaPromocao = bundle.getBoolean("BUSCA_POR_PROMOCAO");
		
		HashMap<String, String> map = new HashMap<String, String>();
		lv = (ListView) findViewById(R.id.listViewEstabelecimentos);

		if (!cidade.equals("")){
			map.put("BUSCA_POR_CIDADE", cidade);
			new ListagemEstabelecimentoAsyncTask(this).execute(map);
		}	
		if (!(idServico==0L)){
			map.put("BUSCA_POR_SERVICOS", Long.toString(idServico));
		    new ListagemEstabelecimentoAsyncTask(this).execute(map);
		}
		    
		if (!(idTipo==0L)){
			map.put("BUSCA_POR_TIPO", Long.toString(idTipo));
		    new ListagemEstabelecimentoAsyncTask(this).execute(map);
		}
		if (buscaPromocao){
			map.put("BUSCA_PROMOCAO", Boolean.toString(buscaPromocao));
		    new ListagemEstabelecimentoAsyncTask(this).execute(map);
		}
		
		
		//Recebe o clique na lista estabelecimento e repassa o id do obj Estabelecimento para EstabelecimentoActivity
		lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

		    @SuppressWarnings("rawtypes")
			@Override
		    public void onItemClick(AdapterView adapter, View viw, int posicao,long id) {
			    Estabelecimento estabelecimento = (Estabelecimento) adapter.getItemAtPosition(posicao);
			    ArrayList<Estabelecimento> listaEstabelecimento = new ArrayList<Estabelecimento>();
			    listaEstabelecimento.add(estabelecimento);
			    
			    Intent it = new Intent(ListagemEstabelecimento.this, EstabelecimentoActivity.class);		 //getBaseContext()   
			    Bundle bundle = new Bundle(); 
			    bundle.putSerializable("lista_estabelecimento", (Serializable) listaEstabelecimento); 
			    it.putExtras(bundle); 
			    startActivity(it);
		    }            
		});

	}
	
	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		
	}
}
