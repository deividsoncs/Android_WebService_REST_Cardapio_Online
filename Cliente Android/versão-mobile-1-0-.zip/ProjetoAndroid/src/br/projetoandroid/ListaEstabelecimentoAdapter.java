package br.projetoandroid;
import java.util.List;
import java.util.concurrent.ExecutionException;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import br.cardapio.bean.Endereco;
import br.cardapio.bean.Estabelecimento;
import br.cardapio.threads.EnderecoAsyncTask;
public class ListaEstabelecimentoAdapter extends ArrayAdapter<Estabelecimento>{
	private Context context;
    private List<Estabelecimento> estabelecimentos = null;
    
    public ListaEstabelecimentoAdapter(Context context,  List<Estabelecimento> estabelecimentos) {
        super(context,0, estabelecimentos);
        this.estabelecimentos = estabelecimentos;
        this.context = context;
    }
    
    @Override
    public View getView(int position, View view, ViewGroup parent) {
        Estabelecimento estabelecimento = estabelecimentos.get(position);
        Endereco enderecoWS = new Endereco();
        //Pega endere�o do WebService
        try {
			enderecoWS = new EnderecoAsyncTask().execute(estabelecimento).get();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}

        if(view == null)
            view = LayoutInflater.from(context).inflate(R.layout.item_estabelecimento_lista, null);
 
        ImageView imageViewEstabelecimento = (ImageView) view.findViewById(R.id.image_view_estabelecimento);
        imageViewEstabelecimento.setImageResource(R.drawable.camera_icon);
         
        TextView textViewNomeFantasia = (TextView) view.findViewById(R.id.text_view_nome_fantasia);
        textViewNomeFantasia.setText(estabelecimento.getNomeFantasia());
         
        TextView textViewSubTitulto = (TextView)view.findViewById(R.id.text_view_endereco);
        
        //Setando valores vindo do WS da EnderecoAsyncTask que faz a tarefa de peso!
        String textoSubTitulto= "Like: " +  String.valueOf(estabelecimento.getGostaram()) + " End: " + enderecoWS.getLogradouro() + ", " + enderecoWS.getBairro() + ", " + enderecoWS.getCidade();
        textViewSubTitulto.setText(textoSubTitulto);
        
        return view;
    }
}
