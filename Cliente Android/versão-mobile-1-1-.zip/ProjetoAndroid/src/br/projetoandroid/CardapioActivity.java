package br.projetoandroid;

import java.util.List;

import br.cardapio.bean.Avaliacao;
import br.cardapio.bean.Cardapio;
import br.cardapio.bean.ItemCardapio;
import br.cardapio.bean.SecaoCardapio;
import br.cardapio.bean.Servicos;
import br.cardapio.requisicao.AvaliacaoReq;
import br.cardapio.requisicao.CardapioReq;
import br.cardapio.requisicao.ItemCardapioReq;
import br.cardapio.requisicao.SecaoCardapioReq;
import br.cardapio.requisicao.ServicoReq;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

public class CardapioActivity extends Activity {
	private Spinner spinnerSecao;
	private long idSecao=0;
	private ListView lv;
	private long idEstabelecimento=0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.cardapio_layout);
		
		//Recebe a opera��o e o par�metro de outra activity
		Bundle bundle = getIntent().getExtras();		
		idEstabelecimento = bundle.getLong("idEstabelecimento");
		
		//Busca o idCardapio no servidor passando o idEstabelecimento
		Cardapio cardapio = new Cardapio();
		cardapio = new CardapioReq().getCardapioPorIdEstabelecimento(idEstabelecimento);
		
		if ((cardapio.getId() != 0)&&(cardapio != null)){
			List<SecaoCardapio> l =  new SecaoCardapioReq().getListaSecaoCardapioPorIdCardapio(cardapio.getId());
			spinnerSecao = (Spinner) findViewById(R.id.spinnerSecao);
			ArrayAdapter<SecaoCardapio> secaoAdapter = new ArrayAdapter<SecaoCardapio>(this, android.R.layout.simple_spinner_item, l);  
			spinnerSecao.setAdapter(secaoAdapter); 
			spinnerSecao.setPrompt("Selecione uma Se��o");
			spinnerSecao.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
				@Override
				public void onItemSelected(AdapterView<?> parent, View v, int posicao, long id) {
					//pega nome pela posi��o			
					SecaoCardapio secao = (SecaoCardapio)parent.getSelectedItem();
					idSecao = secao.getId();
					Log.i("CardapioActivity:", "idSecao="+Long.toString(idSecao));
				}
				@Override
				public void onNothingSelected(AdapterView<?> parent) {
	 
				}
			});
		    
			getListenerBtAtualizarItemCardapio();
		}else{
			Log.i("CardapioActivity:", "IdCardapio � 0");
			Toast.makeText(this, "N�o h� card�pio cadastrado para o estabelecimento desejado!", Toast.LENGTH_SHORT).show();
		}
	}

	private void getListenerBtAtualizarItemCardapio() {
		Button btListarItemCardapio = (Button) findViewById(R.id.bt_listar_itens_cardapio);
		btListarItemCardapio.setOnClickListener(new OnClickListener() { 
		@Override
		public void onClick(View v) {
			//Intent it;
			switch (v.getId()){
			case R.id.bt_listar_itens_cardapio:
				List<ItemCardapio> l = new ItemCardapioReq().getListaItemCardapioPorIdSecaoCardapio(idSecao);
				ListaItemCardapioAdapter itemCardapioAdapter = new ListaItemCardapioAdapter(CardapioActivity.this,  l);
				lv = (ListView) findViewById(R.id.lv_item_cardapio);
			    lv.setAdapter((ListAdapter) itemCardapioAdapter);		
				
				/*
				it = new Intent("LISTAGEM_ESTABELECIMENTO");
				//Seta o que ser� passado CIDADE e Reseta TODOS OUTROS!
				it.putExtra("BUSCA_POR_CIDADE", "");
				it.putExtra("BUSCA_POR_SERVICOS", idServico);
				startActivity(it);
				*/
			}		
		}
	});
	}
	
}
