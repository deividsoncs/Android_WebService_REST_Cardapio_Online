package br.projetoandroid;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import br.cardapio.bean.Endereco;
import br.cardapio.bean.Estabelecimento;
import br.cardapio.requisicao.EnderecoReq;
import br.cardapio.requisicao.EstabelecimentoReq;
import br.cardapio.threads.EnderecoAsyncTask;
import br.cardapio.threads.EstabelecimentoGosteiAsyncTask;
import android.app.Activity;
import android.util.Log;
import android.view.View.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

@SuppressWarnings("serial")
public class EstabelecimentoActivity extends Activity implements Serializable, OnClickListener{
	
	private ArrayList<Estabelecimento> listaEstabelecimento = new ArrayList<Estabelecimento>();
	private Estabelecimento estabelecimento = new Estabelecimento();
	
	@SuppressWarnings("unchecked")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.estabelecimento_layout);
		
		TextView tvNomeFantasia = (TextView) findViewById(R.id.tvNomeFantasia);
		TextView tvEmail = (TextView) findViewById(R.id.tvEmail);
		TextView tvTelefone = (TextView) findViewById(R.id.tvTelefone);
		TextView tvGostaram = (TextView) findViewById(R.id.tvGostaram);
		TextView tvEndereco = (TextView)findViewById(R.id.tvEndereco);
		
		//Recebe a opera��o e o par�metro de outra activity

		Intent intent = getIntent();
		Bundle params = intent.getExtras();  
		if(params!=null){   
			listaEstabelecimento = (ArrayList<Estabelecimento>) params.getSerializable("lista_estabelecimento");
			estabelecimento = listaEstabelecimento.get(0);
			
			//Abre Async Task e busca endereco novamente, n�o � o ideal, pois deveria vir da Activity ListagemEstabelecimento!
			Endereco endereco = new Endereco();
			try {
				endereco = new EnderecoAsyncTask().execute(estabelecimento).get();
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (ExecutionException e) {
				e.printStackTrace();
			} 
			
			tvNomeFantasia.setText(estabelecimento.getNomeFantasia());
			tvEmail.setText(estabelecimento.getEmail());
			tvTelefone.setText("Telefone: " + estabelecimento.getTelefone());
			tvGostaram.setText("Likes: " + Integer.valueOf(estabelecimento.getGostaram()));
			tvEndereco.setText(" End: " + endereco.getLogradouro() + ", " + endereco.getBairro() + ", " + endereco.getCidade());
		}	
		
		ImageButton imageBtLike = (ImageButton) findViewById(R.id.imageBtLike);
		imageBtLike.setOnClickListener(this);
		
		ImageButton imageBtAvaliacao = (ImageButton) findViewById(R.id.imageBtAvaliacao);
		imageBtAvaliacao.setOnClickListener(this);
		
		ImageButton imageBtCardapio = (ImageButton) findViewById(R.id.imageBtCardapio);
		imageBtCardapio.setOnClickListener(this);
	}
	
	public void onClick(View v) {
		Intent it;
		switch (v.getId()){
		case R.id.imageBtLike:
			estabelecimento.setGostaram(estabelecimento.getGostaram() + 1);
			//TextView tvGostaram = (TextView) v.findViewById(R.id.tvGostaram);
			try {
				Toast.makeText(this, (CharSequence) new EstabelecimentoGosteiAsyncTask(this).execute(estabelecimento).get() , Toast.LENGTH_SHORT).show();
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (ExecutionException e) {
				e.printStackTrace();
			}
			
			break;
		case R.id.imageBtAvaliacao:
			it = new Intent(getApplicationContext(), AvalicaoActivity.class);
			Log.i("EstabelecimentoActivity", "IdEstabelecimento= " + Long.toString(estabelecimento.getId()) );
			it.putExtra("idEstabelecimento", estabelecimento.getId());
			startActivity(it);
			break;
		case R.id.imageBtCardapio:
			it = new Intent(getApplicationContext(), CardapioActivity.class);
			Log.i("EstabelecimentoActivity", "IdEstabelecimento= " + Long.toString(estabelecimento.getId()) );
			it.putExtra("idEstabelecimento", estabelecimento.getId());
			startActivity(it);
			break;
		}
		
	}
}
