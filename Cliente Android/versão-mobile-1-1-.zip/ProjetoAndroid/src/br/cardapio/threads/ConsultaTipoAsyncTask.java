package br.cardapio.threads;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.AsyncTask;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import br.cardapio.bean.TipoEstabelecimento;
import br.cardapio.requisicao.TipoEstabelecimentoReq;
import br.projetoandroid.R;

public class ConsultaTipoAsyncTask extends AsyncTask<Void, Object, List<TipoEstabelecimento>> {
	private Activity activity;
   
    public ConsultaTipoAsyncTask(Activity activity) {
        this.activity = activity;
    }
    
	public List<TipoEstabelecimento> doInBackground(Void... params){
    	List<TipoEstabelecimento> listaTipo = new ArrayList<TipoEstabelecimento>();
    	listaTipo = new TipoEstabelecimentoReq().getListaTipoEstabelecimento();
    	
        return listaTipo;

    }

    public void onPostExecute(List<TipoEstabelecimento> l) {
    	Spinner spinnerServicos = (Spinner) activity.findViewById(R.id.spinnerTipos);
		ArrayAdapter<TipoEstabelecimento> tipoAdapter = new ArrayAdapter<TipoEstabelecimento>(activity, android.R.layout.simple_spinner_item, l);  
		spinnerServicos.setAdapter(tipoAdapter); 
    }
}