package br.cardapio.threads;

import android.app.Activity;
import android.os.AsyncTask;
import android.widget.TextView;
import br.cardapio.bean.Estabelecimento;
import br.cardapio.requisicao.EstabelecimentoReq;
import br.projetoandroid.R;

public class EstabelecimentoGosteiAsyncTask extends AsyncTask<Estabelecimento, Object, String>  {
	private Activity activity;
	
    public EstabelecimentoGosteiAsyncTask(Activity activity) {
        this.activity = activity;
    }
    
	public String doInBackground(Estabelecimento... estabelecimento){
		String result = new EstabelecimentoReq().altera(estabelecimento[0]);
        return result;
    }

    public void onPostExecute(Estabelecimento estabelecimento) {
    	TextView tvGostaram = (TextView) activity.findViewById(R.id.tvGostaram);
		tvGostaram.setText("Likes: " + Integer.valueOf(estabelecimento.getGostaram()));
    }

}