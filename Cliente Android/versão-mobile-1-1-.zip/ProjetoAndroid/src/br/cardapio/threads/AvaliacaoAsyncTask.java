package br.cardapio.threads;

import java.util.List;

import android.app.Activity;
import android.os.AsyncTask;
import android.widget.ListAdapter;
import android.widget.ListView;
import br.cardapio.bean.Avaliacao;
import br.cardapio.listas.AvaliacaoList;
import br.cardapio.requisicao.AvaliacaoReq;
import br.projetoandroid.ListaAvaliacaoAdapter;
import br.projetoandroid.R;

public class AvaliacaoAsyncTask extends AsyncTask <Long, Object, List<Avaliacao>>  {
	private Activity activity;
	private ListView lv;
    public AvaliacaoAsyncTask(Activity activity) {
        this.activity = activity;
    }
    
	public List<Avaliacao> doInBackground(Long... idEstabelecimento){
		AvaliacaoList lista = new AvaliacaoList(); 
		lista.setLista(new AvaliacaoReq().getListaPorIdEstabelecimento(idEstabelecimento[0]));
        return lista.getLista();
    }

    @SuppressWarnings("unchecked")
	public void onPostExecute(List<Avaliacao>... l) {
    	ListaAvaliacaoAdapter avaliacaoAdapter = new ListaAvaliacaoAdapter(activity,  l[0]);
		lv = (ListView) activity.findViewById(R.id.listViewAvaliacao);
	    lv.setAdapter((ListAdapter) avaliacaoAdapter);	
    }

}