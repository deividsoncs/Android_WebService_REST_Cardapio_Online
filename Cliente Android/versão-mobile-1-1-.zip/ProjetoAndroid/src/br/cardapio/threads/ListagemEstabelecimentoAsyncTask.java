package br.cardapio.threads;

import java.util.HashMap;
import java.util.List;

import android.app.Activity;
import android.os.AsyncTask;
import android.widget.ListAdapter;
import android.widget.ListView;
import br.cardapio.bean.Estabelecimento;
import br.cardapio.listas.EstabelecimentoList;
import br.cardapio.requisicao.EstabelecimentoReq;
import br.projetoandroid.ListaEstabelecimentoAdapter;
import br.projetoandroid.R;

public class ListagemEstabelecimentoAsyncTask extends AsyncTask<HashMap<String, String>, Object, List<Estabelecimento>> {

	    private Activity activity;
	    private ListView lv;
	   
	    public ListagemEstabelecimentoAsyncTask(Activity activity) {
	        this.activity = activity;
	    }

	    @SuppressWarnings("unchecked")
		public List<Estabelecimento> doInBackground(HashMap<String, String>...map){
	    	EstabelecimentoList listaEstabelecimento = new EstabelecimentoList();
	    	//Verifica qual foi a constante passada para executar o adequado m�todo busca no WS
	    	if (map[0].containsKey("BUSCA_POR_CIDADE")){    
		        listaEstabelecimento = new EstabelecimentoList();
		        listaEstabelecimento.setLista(new EstabelecimentoReq().getListaEstabelecimentoPorCidade(map[0].get("BUSCA_POR_CIDADE").toString()).getLista());
	    	}
	    	
	    	if (map[0].containsKey("BUSCA_POR_SERVICOS")){     
		        listaEstabelecimento = new EstabelecimentoList();
		        listaEstabelecimento.setLista(new EstabelecimentoReq().getEstebelecimentoPorIdServico(Long.valueOf(map[0].get("BUSCA_POR_SERVICOS"))).getLista());
	    	}
	    	
	    	if (map[0].containsKey("BUSCA_POR_TIPO")){     
		        listaEstabelecimento = new EstabelecimentoList();
		        listaEstabelecimento.setLista(new EstabelecimentoReq().getEstebelecimentoPorIdTipo(Long.valueOf(map[0].get("BUSCA_POR_TIPO"))).getLista());
	    	}
	        
	    	if (map[0].containsKey("BUSCA_PROMOCAO")){     
		        listaEstabelecimento = new EstabelecimentoList();
		        listaEstabelecimento.setLista(new EstabelecimentoReq().getListaEstabelecimentoPorPromocao().getLista());
	    	}
	    	
	        return listaEstabelecimento.getLista();

	    }

	    public void onPostExecute(List<Estabelecimento> l) {
	    	ListaEstabelecimentoAdapter estabelecimentosAdapter = new ListaEstabelecimentoAdapter(activity,  l);
			lv = (ListView) activity.findViewById(R.id.listViewEstabelecimentos);
		    lv.setAdapter((ListAdapter) estabelecimentosAdapter);	
	    }
	}
