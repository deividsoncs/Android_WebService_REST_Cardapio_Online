package br.cardapio.requisicao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import br.cardapio.bean.ItemCardapio;
import br.cardapio.listas.ItemCardapioList;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class ItemCardapioReq {
	
	public List<ItemCardapio> getListaItemCardapioPorIdSecaoCardapio (long idSecaoCardapio){
		ItemCardapioList itemCardapioList  = new ItemCardapioList();
		try{
                    URL url = new URL("http://"+Conexao.getSERVIDOR()+"/cardapio.online/rest/recursos/busca_item_cardapio_lista_android/" + idSecaoCardapio);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    if (con.getResponseCode() != 200)
                            throw new RuntimeException("HTTP error code : "+ con.getResponseCode());
                    BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));
	                
                    GsonBuilder builder = new GsonBuilder();
        	        builder.setDateFormat("dd/MM/yyyy");
        	        Gson gson = builder.create();
        	        itemCardapioList = gson.fromJson(br, ItemCardapioList.class);
                    
                    con.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
		return itemCardapioList.getLista();
	}
   
	/*
    public ItemCardapio getItemCardapioPorId(long idItemCardapio){
        ItemCardapio itemCardapio = new ItemCardapio();
        try{
            URL url = new URL("http://localhost:8080/cardapio.online/rest/recursos/busca_item_cardapio/" + idItemCardapio);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            if (con.getResponseCode() != 200)
                    throw new RuntimeException("HTTP error code : "+ con.getResponseCode());
            BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));
            
            //C�digo
            
            
            con.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return itemCardapio;
    }
    */
        
}
