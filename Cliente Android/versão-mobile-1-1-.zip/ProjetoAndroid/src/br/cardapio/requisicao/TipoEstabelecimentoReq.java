package br.cardapio.requisicao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import com.google.gson.Gson;

import br.cardapio.bean.TipoEstabelecimento;
import br.cardapio.listas.TipoEstabelecimentoList;

public class TipoEstabelecimentoReq {
	
	
	
	//Lista Todos Tipos Estabelecimentos
	public  List<TipoEstabelecimento>  getListaTipoEstabelecimento (){
		TipoEstabelecimentoList tipoEstabelecimentoList  = new TipoEstabelecimentoList();
		try{
	        URL url = new URL("http://"+Conexao.getSERVIDOR()+"/cardapio.online/rest/recursos/busca_todos_tipo_estabelecimento_android");
	        HttpURLConnection con = (HttpURLConnection) url.openConnection();
	        if (con.getResponseCode() != 200)
	                throw new RuntimeException("HTTP error code : "+ con.getResponseCode());
	        BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));
	        tipoEstabelecimentoList = new Gson().fromJson(br, TipoEstabelecimentoList.class);       
	        con.disconnect();
	    } catch (IOException e) {
	        e.printStackTrace();
	    } 
		return tipoEstabelecimentoList.getLista();
	}	
	
	public List<TipoEstabelecimento> getListaTipoEstabelecimentoPorIdEstabelecimento (long idEstabelecimento){
		TipoEstabelecimentoList tipoEstabelecimentoList  = new TipoEstabelecimentoList();
		try{
	        URL url = new URL("http://"+Conexao.getSERVIDOR()+"/cardapio.online/rest/recursos/busca_tipo_estabelecimento/" + idEstabelecimento);
	        HttpURLConnection con = (HttpURLConnection) url.openConnection();
	        if (con.getResponseCode() != 200)
	                throw new RuntimeException("HTTP error code : "+ con.getResponseCode());
	        BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));
	        tipoEstabelecimentoList = new Gson().fromJson(br, TipoEstabelecimentoList.class); 
	        con.disconnect();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
		return tipoEstabelecimentoList.getLista();
	}	
}
