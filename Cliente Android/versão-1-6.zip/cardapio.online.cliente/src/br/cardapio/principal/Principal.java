package br.cardapio.principal;

import java.io.ObjectInputStream.GetField;
import java.text.ParseException;
import java.text.SimpleDateFormat;



import java.util.Calendar;
import java.util.Date;

import javax.swing.JOptionPane;

import br.cardapio.bean.Avaliacao;
import br.cardapio.bean.Cardapio;
import br.cardapio.bean.Endereco;
import br.cardapio.bean.Estabelecimento;
import br.cardapio.bean.EstabelecimentoServico;
import br.cardapio.bean.EstabelecimentoTipoEstabelecimento;
import br.cardapio.bean.ItemCardapio;
import br.cardapio.bean.SecaoCardapio;
import br.cardapio.bean.Servicos;
import br.cardapio.bean.TipoEstabelecimento;
import br.cardapio.bean.UsuarioEstabelecimento;
import br.cardapio.formulario.SelecaoEstabelecimentoJFrame;
import br.cardapio.requisicao.AvaliacaoReq;
import br.cardapio.requisicao.CardapioReq;
import br.cardapio.requisicao.EnderecoReq;
import br.cardapio.requisicao.EstabelecimentoReq;
import br.cardapio.requisicao.EstabelecimentoServicoReq;
import br.cardapio.requisicao.EstabelecimentoTipoEstabelecimentoReq;
import br.cardapio.requisicao.ItemCardapioReq;
import br.cardapio.requisicao.SecaoCardapioReq;
import br.cardapio.requisicao.ServicoReq;
import br.cardapio.requisicao.TipoEstabelecimentoReq;
import br.cardapio.requisicao.UsuarioEstabelecimentoReq;

public class Principal {

	public static void main(String[] args) {
		
		/**TESTES!
		 * 
		USUARIOS:
		____________________________________________________________________________________________________________
		//Teste retornar lista de usuarios buscando por nomes OK
		new UsuarioEstabelecimentoReq().getListaUsuarioEstabelecimentoPorNome("Dei");
		
		new EnderecoReq().getEnderecoPorIdEstabelecimento(4);
		
		//UsuarioEstabelecimento usuarioEstabelecimento = new UsuarioEstabelecimento("Helio", "baixinho", "brasil10");
		//new UsuarioEstabelecimentoReq().adiciona(usuarioEstabelecimento);
		
	    //Teste autentica��o OK
		UsuarioEstabelecimento usuarioEstabelecimento = new UsuarioEstabelecimento(0 ,"Helio", "baixinho", "brasil10");
		new UsuarioEstabelecimentoReq().autentica(usuarioEstabelecimento);
		
		//Teste atera��o OK
		UsuarioEstabelecimento usuarioTesteAltera = new UsuarioEstabelecimento(4 ,"Sergio Cardoso", "seginhoborlote", "chile10");
		new UsuarioEstabelecimentoReq().altera(usuarioTesteAltera);
		
		//Teste remo��o: OK
		new UsuarioEstabelecimentoReq().remove(4);
		
		//Teste Listar Todos usuarios OK
		new UsuarioEstabelecimentoReq().getListaUsuarioEstabelecimento();
		
		
		ESTABELECIMENTOS:
		____________________________________________________________________________________________________________
				
		//Teste Listar todos Estabelecimentos OK
		new EstabelecimentoReq().getListaEstabelecimentos();
		
		//Teste Listar todos Estabelecimentos Por Promo��o OK
		new EstabelecimentoReq().getListaEstabelecimentoPorPromocao();
		
		// Teste de Retornar a lista dos Estabelecimentos passando o Nome do Estabelecimento OK
		new EstabelecimentoReq().getListaEstabelecimentoPorNome("Belo");
		
		//> Retornar a lista dos Estabelecimentos passando a Cidade. OK
		new EstabelecimentoReq().getListaEstabelecimentoPorCidade("Vitoria");

		//> Retornar a lista dos Estabelecimentos passando a Cidade. OK
		new EstabelecimentoReq().getListaEstabelecimentoPorCidade("1");
		
		//> Retornar a lista dos Estabelecimentos passando a ID do Servi�os selecionado, ex.: Todos estabelecimento que possuem "m�sica ao vivo" OK
		new EstabelecimentoReq().getEstebelecimentoPorIdServico(2);

		// Lista todos Estabelecimentos pelos id do TipoEstabelecimento passado! Ex.: Lista de Estabelecimentos que s�o churrascarias. OK
		new EstabelecimentoReq().getEstebelecimentoPorIdTipo(5);
		
		//Teste Insere um novo Estabelecimento OK
		Estabelecimento estabelecimento = new Estabelecimento(1, "Betel Cormercio S/A", "Topa Tudo 100", "33369990", "betel@mg.com", "//1/2/logo.jpeg", 100);
		new EstabelecimentoReq().adiciona(estabelecimento);
		
		// Teste Altera um novo Estabelecimento OK
		Estabelecimento estabelecimento = new Estabelecimento(5, 1, "Betel Cormercio LTDA", "Topa Tudo", "33360000", "betelzinho@mg.com", "//1/2/logo2.jpeg", 54);
		new EstabelecimentoReq().altera(estabelecimento);
		
		//Teste Excluir Estabelecimento OK
		new EstabelecimentoReq().remove(5);
		
		//Teste Lista Estabelecimentos por Login Usuario OK
		//new EstabelecimentoReq().getListaEstabelecimentoPorLogin("calixto");
			
		AVALIA��O:
		____________________________________________________________________________________________________________
		
		//Teste adiciona uma nova Avaliacao OK
		Avaliacao avaliacao = new Avaliacao(1,"Muito legal e divertido!", 1);
		new AvaliacaoReq().adiciona(avaliacao);
		
		//Teste Altera uma Avalia��o OK
		Avaliacao avaliacao = new Avaliacao(3, 1, "Ruim demais!", -1);
		new AvaliacaoReq().altera(avaliacao);
		
		//Teste Remove Avalia��o pelo id passado OK
		new AvaliacaoReq().remove(3);
		
		//Teste Buscar todas Avalia��es OK
		new AvaliacaoReq().getListaPorIdEstabelecimento(1);
		
		CARD�PIO:
		____________________________________________________________________________________________________________
		
		//Teste Adiciona Cardapio OK
		Calendar c = Calendar.getInstance();
		c.set(1984, Calendar.JANUARY, 05);
		Cardapio cardapio = new Cardapio(1, c.getTime());
		new CardapioReq().adiciona(cardapio);
		
		//Teste Altera Card�pio OK
		Calendar c = Calendar.getInstance();
		c.set(1959, Calendar.FEBRUARY, 28);
		Cardapio cardapio = new Cardapio(1, 1, c.getTime());
		new CardapioReq().altera(cardapio);
		
		//Teste Remove Card�pio OK
		new CardapioReq().remove(4);
		
		//Teste Restorna Cardapio passa o ID do Estabelecimento!!! OK
		new CardapioReq().getCardapioPorIdEstabelecimento(1);
		
		ENDERE�O:
		____________________________________________________________________________________________________________
		

		//Teste Adiciona Endereco OK
		Endereco endereco = new Endereco(4,"29060132",196, "Loja 047", "Rua Tupinabas", "ES", "Vit�ria", "Jardim da Penha");
		new EnderecoReq().adiciona(endereco);

		//Teste Altera um Endere�o OK
		Endereco endereco = new Endereco(4,"29060",196, "Loja 047", "Rua Tupinabas", "ES", "Vit�ria", "Jardim da Penha");
		new EnderecoReq().altera(endereco);
		
		//Teste Removo um Endere�o pelo id OK
		new EnderecoReq().remove(3);
		
		
		//Teste Retorna o Endere�o pelo idEstabelecimento Passado OK
		new EnderecoReq().getEnderecoPorIdEstabelecimento(4);	
		
		ITEM CARD�PIO:
		____________________________________________________________________________________________________________
		
		//Teste adiciona um no ITEM CARDAPIO OK
		Calendar c = Calendar.getInstance();
		c.set(2014, Calendar.FEBRUARY, 28);
		ItemCardapio itemCardapio = new ItemCardapio(1, "Peroa Frito", 12.50, "Delicioso, frito, com bananas", "//1/1/peroa.jpeg", 0.0, c.getTime());
		new ItemCardapioReq().adiciona(itemCardapio);
		
		
		// Teste Altera um ITEM CARDAPIO OK
		Calendar c = Calendar.getInstance();
		c.set(2013, Calendar.JANUARY, 11);
		ItemCardapio itemCardapio = new ItemCardapio(5 ,1, "Peroa", 12.50, "Delicioso com bananas", "peroajpeg", null, c.getTime());
		new ItemCardapioReq().altera(itemCardapio);
		
		//Teste remove ITEM CARDAPIO pelo ID passado. OK
		new ItemCardapioReq().remove(5);	
		
		//Teste retorna lista dos Item Cardapio pela se��o OK
		new ItemCardapioReq().getListaItemCardapioPorIdSecaoCardapio(1);
		
		
		SE��O CARD�PIO:
		____________________________________________________________________________________________________________
				
		//Teste Adicionado nova SE��O CARDAPIO OK
		SecaoCardapio secaoCardapio = new SecaoCardapio(1, "Entradas!");
		new SecaoCardapioReq().adiciona(secaoCardapio);
		
		//Teste Altera uma Se��o Cardapio OK
		SecaoCardapio secaoCardapio = new SecaoCardapio(4 , 1, "Entradas");
		new SecaoCardapioReq().altera(secaoCardapio);
		
		//Teste Remove SecaoCardapio pelo id passado OK
		new SecaoCardapioReq().remove(4);
		
		//Teste Retorna uma lista de Secao Cardapio referente ao ID do Cardapio OK
		new SecaoCardapioReq().getListaSecaoCardapioPorIdCardapio(1);
		
		
		SERVI�OS:
		____________________________________________________________________________________________________________
		
		//Teste Insere um novo Servi�o OK
		Servicos servico = new Servicos("Entrega Cometa!");
		new ServicoReq().adiciona(servico);
		
		//Teste Altera um Servi�o OK
		new ServicoReq().altera(new Servicos(6, "Rapidao!"));
		
		//Teste Remove um Servi�o OK
		new ServicoReq().remove(6);
		
		//Listar todos Servi�os OK
		new ServicoReq().getListaServicos();
		
		//Lista todos servicos pelo id do Estabelecimento passado! OK
		new ServicoReq().getListaServicoPorIdEstabelecimento(1);
		
		ESTABELECIMENTO_SERVICO :
		____________________________________________________________________________________________________________
		
		//Teste adiciona novo Estabelecimento Servico OK
		new EstabelecimentoServicoReq().adiciona(new EstabelecimentoServico(4, 2));
		
		//Teste altera um estabelecimento_servico OK
		new EstabelecimentoServicoReq().altera(new EstabelecimentoServico(5, 4, 5));
		
		//Teste remove um Estabelecimento Servico
		new EstabelecimentoServicoReq().remove(5);
		
		TIPO ESTABELECIMENTO
		____________________________________________________________________________________________________________
		
		//Teste adiciona novo Tipo Estabelecimento OK
		new TipoEstabelecimentoReq().adiciona(new TipoEstabelecimento("pizzaria"));
		
		//Teste altera Tipo Estabelecimento OK
		new TipoEstabelecimentoReq().altera(new TipoEstabelecimento(9, "esfirreria"));
		
		//Teste remove  Tipo Estabelecimento OK
		new TipoEstabelecimentoReq().remove(9);
		
		//Teste busca lista de todos Tipo Estabelecimento OK
		new TipoEstabelecimentoReq().getListaTipoEstabelecimento();
		
		//Teste busca lista de todos Tipo Estabelecimento por IdEstabelecimento  OK
		new TipoEstabelecimentoReq().getListaTipoEstabelecimentoPorIdEstabelecimento(1);
		
		ESTABELECIMENTO TIPO ESTABELECIMENTO
		____________________________________________________________________________________________________________	
		
		//Teste adiciona EstabelecimentoTipoEstabelecimento OK
		new EstabelecimentoTipoEstabelecimentoReq().adiciona(new EstabelecimentoTipoEstabelecimento(4, 8));
		
		//Teste remove EstabelecimentoTipoEstabelecimento OK
		new EstabelecimentoTipoEstabelecimentoReq().remove(6);
		
		//Teste altera EstabelecimentoTipoEstabelecimento OK
		new EstabelecimentoTipoEstabelecimentoReq().altera(new EstabelecimentoTipoEstabelecimento(5, 4, 6));
		
		*/

	
				
	}

}
;