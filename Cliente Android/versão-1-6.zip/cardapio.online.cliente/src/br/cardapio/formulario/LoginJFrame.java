package br.cardapio.formulario;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import br.cardapio.bean.UsuarioEstabelecimento;
import br.cardapio.requisicao.UsuarioEstabelecimentoReq;

@SuppressWarnings("serial")
public class LoginJFrame extends JInternalFrame{
	JTextField tfLogin  = new JTextField(10);
	JPasswordField pfSenha  = new JPasswordField(10);
	
	JLabel lbLogin, lbSenha;
	JButton btOk, btSair;
	
	
	public LoginJFrame(){
		super("Tela de Login", false, true, false, false);//resizable closable maximizable iconifiable
		setSize(200,130);
		//panel.setBackground(Color.GREEN);
		
		lbLogin = new JLabel("Login: ");  
		tfLogin = new JTextField();
		tfLogin.setColumns(10);
		
		
		lbSenha = new JLabel("Senha: ");
        pfSenha = new JPasswordField();
        pfSenha.setColumns(10);
        
        btOk = new JButton("Ok");
        btSair = new JButton("Sair");
        
        JPanel painel = new JPanel();;
        
		painel.add (lbLogin);
		painel.add(tfLogin);
		painel.add(lbSenha);
		painel.add(pfSenha);
		painel.add(btOk);
		painel.add(btSair);
		
		Container container = getContentPane();
		container.add(painel);
		
		
		
		btOk.addActionListener(new ActionListener(){
			 
            public void actionPerformed(ActionEvent evt){
            	UsuarioEstabelecimento usuarioEstabelecimentoLogon = new UsuarioEstabelecimento();
            	UsuarioEstabelecimento usuarioEstabelecimentoBanco;
            	
                String senha = new String(pfSenha.getPassword());
                usuarioEstabelecimentoLogon.setLogin(tfLogin.getText());
                usuarioEstabelecimentoLogon.setSenha(senha);
                usuarioEstabelecimentoBanco = new UsuarioEstabelecimentoReq().autentica(usuarioEstabelecimentoLogon);
                if (usuarioEstabelecimentoBanco  != null){
                	br.cardapio.formulario.Principal.STATUS = 1;
                	br.cardapio.formulario.Principal.LOGIN = usuarioEstabelecimentoBanco.getLogin();
                	br.cardapio.formulario.Principal.ID_LOGIN = usuarioEstabelecimentoBanco.getId();
                	JOptionPane.showMessageDialog(null, "Logado como: " + usuarioEstabelecimentoBanco.getLogin());                	
                	System.out.println(usuarioEstabelecimentoLogon.getId());
                	
                }else{
                    JOptionPane.showMessageDialog(null, "Senha ou Login incorreto ou inexistente!");
                    br.cardapio.formulario.Principal.STATUS = 0;
                }   
            }
        });
		
		
   }	
}

