package br.cardapio.formulario;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

@SuppressWarnings("serial")
public class Principal extends JFrame {
    public JDesktopPane desktopPane;
    private JMenuItem menuItemLogin, menuItemSelecaoEstabelecimento, menuItemCadastroEstabelecimento, menuItemCadastroEnderecoEstabelecimento;
    private JMenuBar menuBar;
    private JMenu menuInicio, menuCadastro, menuConsulta, logon;
    private LoginJFrame loginJFrame;
    private SelecaoEstabelecimentoJFrame selecaoEstabelecimentoJFrame;
    private CadastroEstabelecimentoJFrame cadastroEstabelecimentoJFrame;
    
    public static int STATUS = 0;
    public 	static String LOGIN = "";
    public static long ID_LOGIN = 0L;
    public static long ID_ESTABELECIMENTO = 0L; 
    
    public void setDesktopPane(JInternalFrame janelaInterna){
    	this.desktopPane.add(janelaInterna);
    	
    }
    
    @SuppressWarnings("deprecation")
	public Principal(){
    	 
        super("Exemplo de JDesktopPane");
 
        int inset = 50;
 
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setBounds(inset, inset,
                   screenSize.width  - inset*2,
                  screenSize.height - inset*2);
 
        desktopPane = new JDesktopPane();
        
        //Monta item do menu OP��ES TELA DE LOGIN
        menuItemLogin = new JMenuItem("Tela de Login");
        menuItemLogin.addActionListener(new ActionListener(){
 
            public void actionPerformed(ActionEvent evt){
 
                if(loginJFrame == null){
                    loginJFrame = new LoginJFrame();
                    loginJFrame.setVisible(true);
                    desktopPane.add(loginJFrame);
                }
                else if(!loginJFrame.isVisible()){
                	loginJFrame.setVisible(true);
                    desktopPane.add(loginJFrame);
                }
            }
        });
 
        
        //Monta item do menu OP��ES TELA DE SELE��O DO ESTABELECIMENTO
        menuItemSelecaoEstabelecimento = new JMenuItem("Tela de Sele��o Estabelecimento");
        menuItemSelecaoEstabelecimento.addActionListener(new ActionListener(){
 
            public void actionPerformed(ActionEvent evt){
 
                if(selecaoEstabelecimentoJFrame == null){
                	selecaoEstabelecimentoJFrame = new SelecaoEstabelecimentoJFrame();
                	selecaoEstabelecimentoJFrame.setVisible(true);
                    desktopPane.add(selecaoEstabelecimentoJFrame);
                }
                else if(!selecaoEstabelecimentoJFrame.isVisible()){
                	selecaoEstabelecimentoJFrame.setVisible(true);
                    desktopPane.add(selecaoEstabelecimentoJFrame);
                }
            }
        });
        
        //Monta item do menu CADATRO CADASTRAR ESTABELECIMENTO
        menuItemCadastroEstabelecimento = new JMenuItem("Cadastrar Estabelecimento");
        menuItemCadastroEstabelecimento.addActionListener(new ActionListener(){
 
            public void actionPerformed(ActionEvent evt){
 
                if(cadastroEstabelecimentoJFrame == null){
                	cadastroEstabelecimentoJFrame = new CadastroEstabelecimentoJFrame();
                	cadastroEstabelecimentoJFrame.setVisible(true);
                    desktopPane.add(cadastroEstabelecimentoJFrame);
                    cadastroEstabelecimentoJFrame.tfIdUsuario.setText(Long.toString(ID_LOGIN));
                }
                else if(!cadastroEstabelecimentoJFrame.isVisible()){
                	cadastroEstabelecimentoJFrame.setVisible(true);
                    desktopPane.add(cadastroEstabelecimentoJFrame);
                    cadastroEstabelecimentoJFrame.tfIdUsuario.setText(Long.toString(ID_LOGIN));
                }
            }
        });
 
        //Monta item do menu CADATRO ENDERE�O ESTABELECIMENTO
        menuItemCadastroEnderecoEstabelecimento = new JMenuItem("Cadastrar Endere�o Estabelecimento");
        menuItemCadastroEnderecoEstabelecimento.addActionListener(new ActionListener(){
 
            public void actionPerformed(ActionEvent evt){
 
                if(cadastroEstabelecimentoJFrame == null){
                	cadastroEstabelecimentoJFrame = new CadastroEstabelecimentoJFrame();
                	cadastroEstabelecimentoJFrame.setVisible(true);
                    desktopPane.add(cadastroEstabelecimentoJFrame);
                    cadastroEstabelecimentoJFrame.tfIdUsuario.setText(Long.toString(ID_LOGIN));
                }
                else if(!cadastroEstabelecimentoJFrame.isVisible()){
                	cadastroEstabelecimentoJFrame.setVisible(true);
                    desktopPane.add(cadastroEstabelecimentoJFrame);
                    cadastroEstabelecimentoJFrame.tfIdUsuario.setText(Long.toString(ID_LOGIN));
                }
            }
        });
        
        

        
        
        //Revisar Esquema para Aparecer o usu�rio logado na barra de menu!
        String strStatus;
        if (STATUS == 1)
        	strStatus = "Logado como: " + LOGIN;
		else
			strStatus = "N�o Logado! ";
       
        logon = new JMenu(strStatus);
        logon.enable(false);
       
        menuBar = new JMenuBar();
        
        menuInicio = new JMenu("Inicio");
        menuBar.add(menuInicio);      
        menuInicio.add(menuItemLogin);
        menuInicio.add(menuItemSelecaoEstabelecimento);
        
        menuCadastro = new JMenu("Cadastros");
        menuBar.add(menuCadastro);
        menuCadastro.add(menuItemCadastroEstabelecimento);
       
        menuBar.add(logon);
        
        setContentPane(desktopPane);
        setJMenuBar(menuBar);
 
        setVisible(true);
        setResizable(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
 
    public static void main(String args[]){
 
       new Principal();
    }
 
}
