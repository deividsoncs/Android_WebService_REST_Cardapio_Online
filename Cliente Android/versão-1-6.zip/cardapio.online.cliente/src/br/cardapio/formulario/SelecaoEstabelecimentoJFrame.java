package br.cardapio.formulario;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import br.cardapio.listas.EstabelecimentoList;
import br.cardapio.requisicao.EstabelecimentoReq;

@SuppressWarnings("serial")
public class SelecaoEstabelecimentoJFrame extends JInternalFrame{
		
	JComboBox <String> jcbEstabelecimentos;
	JLabel lbEstabelecimentos;
	JButton btOk, btSair, btBuscar;
	EstabelecimentoList listaEstabelecimento = new EstabelecimentoList();
	ArrayList <Integer> listaIdentificadorEstabelecimento = new ArrayList<Integer>();
	
	public SelecaoEstabelecimentoJFrame(){
		super("Sele��o do Estabelecimento", false, true, false, false);//resizable closable maximizable iconifiable  
		setSize(900,80);  	
		
        btOk = new JButton("Ok");
        btBuscar = new JButton("Carregar Estabelecimentos");
        btSair = new JButton("Sair");
        
        lbEstabelecimentos = new JLabel("Estabelecimentos: ");
        jcbEstabelecimentos = new JComboBox<String>();
        jcbEstabelecimentos.setSize(250, 20);
        
        
        JPanel painel = new JPanel();;
        
        painel.add(btBuscar);
		painel.add(lbEstabelecimentos);
		painel.add(jcbEstabelecimentos);
		
		painel.add(btOk);
		painel.add(btSair);
		
		Container container = getContentPane();
		container.add(painel);
		
		//Carrega o o COMBOBOX com os estabelecimentos referenco ao Usuario Logado! Quando se clica em btBuscar
		btBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {	
				listaEstabelecimento.setLista(new EstabelecimentoReq().getListaEstabelecimentoPorLogin(br.cardapio.formulario.Principal.LOGIN).getLista());	
				jcbEstabelecimentos.removeAllItems();
				for (int registro = 0; registro < listaEstabelecimento.getLista().size(); registro++){ 
					//System.out.println(listaEstabelecimento.getLista().get(registro).getNomeFantasia()); 
					jcbEstabelecimentos.addItem(listaEstabelecimento.getLista().get(registro).getNomeFantasia());
					listaIdentificadorEstabelecimento.add((int) listaEstabelecimento.getLista().get(registro).getId());
				}
			}
		});
		
		//Seleciona Estabelecimento para efetuar o controle deste
		
		btOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {	
				br.cardapio.formulario.Principal.ID_ESTABELECIMENTO = listaIdentificadorEstabelecimento.get(jcbEstabelecimentos.getSelectedIndex());
				System.out.println(br.cardapio.formulario.Principal.ID_ESTABELECIMENTO);
			}
		});
	}
}
