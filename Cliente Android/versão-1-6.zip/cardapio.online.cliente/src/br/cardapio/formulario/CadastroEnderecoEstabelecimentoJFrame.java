package br.cardapio.formulario;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import br.cardapio.bean.Endereco;
import br.cardapio.bean.Estabelecimento;
import br.cardapio.requisicao.EstabelecimentoReq;

public class CadastroEnderecoEstabelecimentoJFrame extends JInternalFrame {
	
	JTextField tfIdEstabelecimento  = new JTextField();
	JTextField tfCep = new JTextField();
	JTextField tfNumero= new JTextField();
	JTextField tfComplemento = new JTextField();
	JTextField tfLogradouro  = new JTextField();
	JTextField tfEstado  = new JTextField();
	JTextField tfCidade  = new JTextField();
	JTextField tfBairro  = new JTextField();
	//Gostaram
	//Imagem
	
	JLabel lbIdEstabelecimento, lbCep, lbNumero, lbComplemento, lbLogradouro, lbEstado, lbCidade, lbBairro;
	
	JButton btOk, btSair, btNovo;

	@SuppressWarnings("deprecation")
	public CadastroEnderecoEstabelecimentoJFrame(){
		super("Cadsatro de Estabelecimentos", false, true, false, false);//resizable closable maximizable iconifiable
		setSize(300,300);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);  
		//panel.setBackground(Color.GREEN);
		
		lbIdEstabelecimento = new JLabel("Cod Estabelecimento: ");  
		tfIdEstabelecimento = new JTextField(Long.toString(br.cardapio.formulario.Principal.ID_ESTABELECIMENTO));
		tfIdEstabelecimento.setColumns(20);
		tfIdEstabelecimento.enable(false);
		System.out.println(br.cardapio.formulario.Principal.ID_ESTABELECIMENTO);
		
		
		lbCep = new JLabel("Cep         : ");
		tfCep = new JTextField();
		tfCep.setColumns(20);
		
		
		lbNumero= new JLabel("N�mero      : ");
		tfNumero = new JTextField();
		tfNumero.setColumns(20);
		
		
		lbComplemento = new JLabel("Complemento  : ");
		tfComplemento = new JTextField();
		tfComplemento.setColumns(20);
		
		lbLogradouro = new JLabel("Logradouro  : ");
		tfLogradouro = new JTextField();
		tfLogradouro.setColumns(20);
		
		lbEstado = new JLabel("Estado     : ");
		tfEstado = new JTextField();
		tfEstado.setColumns(20);
		
		lbCidade= new JLabel("Cidade       : ");
		tfCidade = new JTextField();
		tfCidade.setColumns(20);
		
		lbBairro = new JLabel("Bairro     : ");
		tfBairro = new JTextField();
		tfBairro.setColumns(20);
		
		
		btNovo = new JButton("Novo");
		
		btOk = new JButton("Salvar");
		
        btSair = new JButton("Sair");
        
        JPanel painel = new JPanel();;
        
		painel.add (lbIdEstabelecimento);
		painel.add (tfIdEstabelecimento);
		
		painel.add (lbCep);
		painel.add (tfCep);
		
		painel.add (lbNumero);
		painel.add (tfNumero);
		
		painel.add (lbComplemento);
		painel.add (tfComplemento);
		
		painel.add (lbLogradouro);
		painel.add (tfLogradouro);
		
		painel.add (lbEstado);
		painel.add (tfEstado);
		
		painel.add (lbCidade);
		painel.add (tfCidade);
		
		painel.add (lbBairro);
		painel.add (tfBairro);
		
		
		painel.add(btNovo);
		painel.add(btOk);
		painel.add(btSair);
		
		Container container = getContentPane();
		container.add(painel);
		
		btOk.addActionListener(new ActionListener(){
			 
            public void actionPerformed(ActionEvent evt){
            	Endereco endereco = new Endereco();
            	endereco.setIdEstabelecimento(Long.valueOf(tfIdEstabelecimento.getText()));
            	endereco.setCep(tfCep.getText());
            	endereco.setNumero(Integer.parseInt(tfNumero.getText()));
            	endereco.setComplemento(tfComplemento.getText());
            	endereco.setLogradouro(tfLogradouro.getText());
            	endereco.setEstado(tfEstado.getText());
            	endereco.setCidade(tfCidade.getText());
            	endereco.setBairro(tfBairro.getText());
            	
            }
        });
		
		btNovo.addActionListener(new ActionListener(){
			 
            public void actionPerformed(ActionEvent evt){
            	/*
            	tfIdUsuario.setVisible(true);
            	tfnomeFantasia.setVisible(true);
            	tfEmail.setVisible(true);
            	tfTelefone.setVisible(true);
            	tfRazaoSocial.setVisible(true);
            	*/
            }
        });	
		
		btSair.addActionListener(new ActionListener(){
			 
            public void actionPerformed(ActionEvent evt){
            	setVisible(false);
            }
        });	
   }	
}
