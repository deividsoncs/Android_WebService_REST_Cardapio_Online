package br.cardapio.formulario;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import br.cardapio.bean.Estabelecimento;
import br.cardapio.requisicao.EstabelecimentoReq;

public class CadastroEstabelecimentoJFrame extends JInternalFrame {
	
	JTextField tfIdUsuario  = new JTextField();
	JTextField tfnomeFantasia = new JTextField();
	JTextField tfEmail  = new JTextField();
	JTextField tfTelefone  = new JTextField();
	JTextField tfRazaoSocial  = new JTextField();
	//Gostaram
	//Imagem
	
	JLabel lbIdUsuario, lbNomeFantasia, lbEmail, lbTelefone, lbRazaoSocial;
	
	JButton btOk, btSair, btNovo;

	@SuppressWarnings("deprecation")
	public CadastroEstabelecimentoJFrame(){
		super("Cadsatro de Estabelecimentos", false, true, false, false);//resizable closable maximizable iconifiable
		setSize(300,300);
		 setDefaultCloseOperation(DISPOSE_ON_CLOSE);  
		//panel.setBackground(Color.GREEN);
		
		lbIdUsuario = new JLabel("Cod Usu�rio  : ");  
		tfIdUsuario = new JTextField(Long.toString(br.cardapio.formulario.Principal.ID_LOGIN));
		tfIdUsuario.setColumns(20);
		tfIdUsuario.enable(false);
		System.out.println(br.cardapio.formulario.Principal.ID_LOGIN);
		
		
		lbNomeFantasia = new JLabel("Nome Fantasia: ");
		tfnomeFantasia = new JTextField();
		tfnomeFantasia.setColumns(20);
		
		
		lbEmail = new JLabel("Email       : ");
		tfEmail = new JTextField();
		tfEmail.setColumns(20);
		
		
		lbTelefone = new JLabel("Telefone    : ");
		tfTelefone = new JTextField();
		tfTelefone.setColumns(20);
		
		lbRazaoSocial = new JLabel("R. Social   : ");
		tfRazaoSocial = new JTextField();
		tfRazaoSocial.setColumns(20);
		
		btNovo = new JButton("Novo");
		
		btOk = new JButton("Salvar");
		
        btSair = new JButton("Sair");
        
        JPanel painel = new JPanel();;
        
		painel.add (lbIdUsuario);
		painel.add (tfIdUsuario);
		
		painel.add (lbNomeFantasia);
		painel.add (tfnomeFantasia);
		
		painel.add (lbEmail);
		painel.add (tfEmail);
		
		painel.add (lbTelefone);
		painel.add (tfTelefone);
		
		painel.add (lbRazaoSocial);
		painel.add (tfRazaoSocial);
		
		painel.add(btNovo);
		painel.add(btOk);
		painel.add(btSair);
		
		Container container = getContentPane();
		container.add(painel);
		
		btOk.addActionListener(new ActionListener(){
			 
            public void actionPerformed(ActionEvent evt){
            	Estabelecimento estabelecimento = new Estabelecimento();
            	estabelecimento.setIdUsuario(Long.valueOf(tfIdUsuario.getText()));
            	estabelecimento.setRazaoSocial(tfRazaoSocial.getText());
            	estabelecimento.setNomeFantasia(tfnomeFantasia.getText());
            	estabelecimento.setEmail(tfEmail.getText());
            	estabelecimento.setTelefone(tfTelefone.getText());
            	//Imagem
                System.out.println("Cliente:" +new EstabelecimentoReq().adiciona(estabelecimento));
            }
        });
		
		btNovo.addActionListener(new ActionListener(){
			 
            public void actionPerformed(ActionEvent evt){
            	/*
            	tfIdUsuario.setVisible(true);
            	tfnomeFantasia.setVisible(true);
            	tfEmail.setVisible(true);
            	tfTelefone.setVisible(true);
            	tfRazaoSocial.setVisible(true);
            	*/
            }
        });	
   }	
}
