package br.cardapio.principal;

import br.cardapio.requisicao.EnderecoReq;
import br.cardapio.requisicao.UsuarioEstabelecimentoReq;

public class Principal {

	public static void main(String[] args) {
		
		new UsuarioEstabelecimentoReq().getTodoUsuarioEstabelecimentoPorNome("Dei");
		
		new EnderecoReq().getEnderecoPorIdEstabelecimento(4);
		
		
	}

}
