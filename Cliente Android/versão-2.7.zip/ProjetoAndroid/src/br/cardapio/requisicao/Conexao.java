package br.cardapio.requisicao;

public class Conexao {
	private static final String SERVIDOR= "192.168.1.100:7777"; 
	//Android: SERVIDOR= LOCALHOST_EMULADOR"10.0.2.2:8080"  LAN: 192.168.1.100:7777  WAN: www.xdvdx.no-ip.org:7777

	public static String getSERVIDOR() {
		return SERVIDOR;
	}
	
	
}
