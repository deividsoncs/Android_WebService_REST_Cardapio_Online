package br.cardapio.listas;

import java.util.ArrayList;
import java.util.List;

import br.cardapio.bean.Avaliacao;

public class AvaliacaoList {

    private List <Avaliacao> lista =  null;

    public List<Avaliacao> getLista() {
		return lista;
	}

	public void setLista(List<Avaliacao> lista) {
		this.lista = lista;
	}

	public AvaliacaoList(){
        lista = new ArrayList<Avaliacao>();
    }

    public void add(Avaliacao novo){
        lista.add(novo);
    }
    
    public boolean isEmpty(){
    	return lista.isEmpty();
    }
    
	public String toString() {
		String str = " ";
		for (Avaliacao objeto : lista){
			str += objeto.toString() + " \n";
		}
		return str;
	}
}

