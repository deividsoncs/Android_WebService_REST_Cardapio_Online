package br.cardapio.listas;

import java.util.ArrayList;
import java.util.List;

import br.cardapio.bean.UsuarioEstabelecimento;


public class UsuarioEstabelecimentoList {
	
    private List <UsuarioEstabelecimento> lista =  null;

    public UsuarioEstabelecimentoList(){
        lista = new ArrayList<UsuarioEstabelecimento>();
    }

    public void add(UsuarioEstabelecimento novo){
        lista.add(novo);
    }
    
    public boolean isEmpty(){
    	return lista.isEmpty();
    }

	@Override
	public String toString() {
		String str = " ";
		for (UsuarioEstabelecimento usuario : lista){
			str += usuario.toString() + " \n";
		}
		/**
		for (int i = 0; i < lista.size(); i++){
			
			UsuarioEstabelecimento usuario = (UsuarioEstabelecimento) lista.get(i);
			System.out.println(usuario.getNome());
			//System.out.println(lista.get(i).getLogin());
		}
		*/
		return str;
	}

    

	
	
    
    
}