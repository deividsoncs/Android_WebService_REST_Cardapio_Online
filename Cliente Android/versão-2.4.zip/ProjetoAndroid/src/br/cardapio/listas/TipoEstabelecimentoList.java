package br.cardapio.listas;


import java.util.ArrayList;
import java.util.List;

import br.cardapio.bean.TipoEstabelecimento;

public class TipoEstabelecimentoList {

    private List <TipoEstabelecimento> lista =  null;

    public TipoEstabelecimentoList(){
        lista = new ArrayList<TipoEstabelecimento>();
    }

    public void add(TipoEstabelecimento novo){
        lista.add(novo);
    }
    
    public boolean isEmpty(){
    	return lista.isEmpty();
    }
    
	public String toString() {
		String str = " ";
		for (TipoEstabelecimento objeto : lista){
			str += objeto.toString() + " \n";
		}
		return str;
	}

	public List<TipoEstabelecimento> getLista() {
		return lista;
	}

	public void setLista(List<TipoEstabelecimento> lista) {
		this.lista = lista;
	}
	
}
