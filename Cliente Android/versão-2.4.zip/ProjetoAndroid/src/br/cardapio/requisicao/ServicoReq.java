package br.cardapio.requisicao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import android.util.Log;
import br.cardapio.bean.Servicos;
import br.cardapio.listas.ServicosList;

import com.google.gson.Gson;

public class ServicoReq {
	
	
	//Lista Todos Servicos
	public List<Servicos> getListaServicos (){
		ServicosList servicosList  = new ServicosList();
		try{
	        URL url = new URL("http://"+ Conexao.getSERVIDOR() +"/cardapio.online/rest/recursos/busca_todos_servicos_android");
	        HttpURLConnection con = (HttpURLConnection) url.openConnection();
	        if (con.getResponseCode() != 200)
	                throw new RuntimeException("HTTP error code : "+ con.getResponseCode());
	        BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));
	        if (br.toString() == ""){
	        	servicosList.add(new Servicos(0,"N�o Encontrado"));
	        	return servicosList.getLista();
	        }
	        //Convers�o
	        servicosList = new Gson().fromJson(br, ServicosList.class);
	        Log.i("TESTE", "retorno Lista   " + servicosList.toString() );  
	        con.disconnect();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
		return servicosList.getLista();
	}	
	
	public ServicosList getListaServicoPorIdEstabelecimento (long idEstabelecimento){
		ServicosList servicosList  = new ServicosList();
		try{
	        URL url = new URL("http://"+ Conexao.getSERVIDOR() +"/cardapio.online/rest/recursos/busca_servicos_android/" + idEstabelecimento);
	        HttpURLConnection con = (HttpURLConnection) url.openConnection();
	        if (con.getResponseCode() != 200)
	                throw new RuntimeException("HTTP error code : "+ con.getResponseCode());
	        BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));
	        if (br.toString() == ""){
	        	servicosList.add(new Servicos(0,"N�o Encontrado"));
	        	return servicosList;
	        }
	        servicosList = new Gson().fromJson(br, ServicosList.class);
	        Log.i("TESTE", "retorno Lista   " + servicosList.toString() );  
	        con.disconnect();
	    } catch (IOException e) {
	        e.printStackTrace();
	    } 
		return servicosList;
	}	
}
