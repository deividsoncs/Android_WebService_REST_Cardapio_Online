package br.cardapio.requisicao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import android.util.Log;
import br.cardapio.bean.Avaliacao;
import br.cardapio.listas.AvaliacaoList;

import com.google.gson.Gson;
public class AvaliacaoReq {

	
	public List<Avaliacao> getListaPorIdEstabelecimento(long idEstabelecimento){
		
		AvaliacaoList avaliacaoList  = new AvaliacaoList();
		avaliacaoList.setLista(null);
		try{
	        URL url = new URL("http://"+ Conexao.getSERVIDOR() +"/cardapio.online/rest/recursos/busca_avaliacao_por_estabelecimento_android/" + idEstabelecimento);
	        HttpURLConnection con = (HttpURLConnection) url.openConnection();
	        
	        if (con.getResponseCode() != 200) {
	                throw new RuntimeException("HTTP error code : "+ con.getResponseCode());
	        }
	        BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));
	        avaliacaoList  = new Gson().fromJson(br, AvaliacaoList.class);
	        
	        if (avaliacaoList.getLista() == null){
	        
	        }
	     	Log.i("TESTE", "getListaPorIdEstabelecimento==[  " + avaliacaoList.toString() + "]"); 
	        con.disconnect();
	        con.disconnect();
	
	    } catch (IOException e) {
	        e.printStackTrace();
		}
		return avaliacaoList.getLista();
	}
	
}
