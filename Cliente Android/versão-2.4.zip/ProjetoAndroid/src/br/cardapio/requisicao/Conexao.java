package br.cardapio.requisicao;

public class Conexao {
	private static final String SERVIDOR= "10.0.2.2:8080";

	public static String getSERVIDOR() {
		return SERVIDOR;
	}
	
	
}
