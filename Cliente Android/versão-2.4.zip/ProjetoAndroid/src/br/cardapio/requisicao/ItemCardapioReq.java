package br.cardapio.requisicao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import br.cardapio.bean.ItemCardapio;
import br.cardapio.listas.ItemCardapioList;

public class ItemCardapioReq {
	
	public ItemCardapioList getListaItemCardapioPorIdSecaoCardapio (long idSecaoCardapio){
		ItemCardapioList itemCardapioList  = new ItemCardapioList();
		try{
                    URL url = new URL("http://localhost:8080/cardapio.online/rest/recursos/busca_item_cardapio_lista/" + idSecaoCardapio);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    if (con.getResponseCode() != 200)
                            throw new RuntimeException("HTTP error code : "+ con.getResponseCode());
                    BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));
                    
                    
                    //C�digo
                    
                    
                    System.out.println(itemCardapioList.toString() + "\n");
                    con.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
		return itemCardapioList;
	}
        
        public ItemCardapio getItemCardapioPorId(long idItemCardapio){
            ItemCardapio itemCardapio = new ItemCardapio();
            try{
                URL url = new URL("http://localhost:8080/cardapio.online/rest/recursos/busca_item_cardapio/" + idItemCardapio);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                if (con.getResponseCode() != 200)
                        throw new RuntimeException("HTTP error code : "+ con.getResponseCode());
                BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));
                
                //C�digo
                
                
                con.disconnect();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return itemCardapio;
        }
        
}
