package br.projetoandroid;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import br.cardapio.bean.Avaliacao;
import br.cardapio.requisicao.AvaliacaoReq;

public class AvalicaoActivity extends Activity {
	private ListView lv;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.avaliacao);
		
		//Recebe a opera��o e o par�metro de outra activity
		Bundle bundle = getIntent().getExtras();		
		long idEstabelecimento = bundle.getLong("idEstabelecimento");
		
		Log.i("AvalicaoActivity", "idEstabelecimento = " + Long.toString(idEstabelecimento));
		if (idEstabelecimento!=0){
			List<Avaliacao> l = new AvaliacaoReq().getListaPorIdEstabelecimento(idEstabelecimento);
			ListaAvaliacaoAdapter avaliacaoAdapter = new ListaAvaliacaoAdapter(this,  l);
			lv = (ListView) findViewById(R.id.listViewAvaliacao);
		    lv.setAdapter((ListAdapter) avaliacaoAdapter);		
		}else{
			List<Avaliacao> l = new ArrayList<Avaliacao>();
			ListaAvaliacaoAdapter avaliacaoAdapter = new ListaAvaliacaoAdapter(this,  l);
			lv = (ListView) findViewById(R.id.listViewAvaliacao);
		    lv.setAdapter((ListAdapter) avaliacaoAdapter);	
		    Toast.makeText(this, "Esse Estabelecimento ainda n�o foi avaliado, seja o primeiro!", Toast.LENGTH_SHORT).show();
		}
	}
}
