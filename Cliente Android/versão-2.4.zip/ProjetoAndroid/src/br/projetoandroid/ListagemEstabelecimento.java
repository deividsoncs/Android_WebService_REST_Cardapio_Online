package br.projetoandroid;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import br.cardapio.bean.Estabelecimento;
import br.cardapio.listas.EstabelecimentoList;
import br.cardapio.requisicao.EstabelecimentoReq;

public class ListagemEstabelecimento extends MainActivity implements OnItemClickListener{

	private static final String CATEGORIA = "cardapio";
	private ListView lv;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.listagem_estabelecimento);
		
		//Recebe a opera��o e o par�metro de outra activity
		
		Bundle bundle = getIntent().getExtras();
		String cidade = bundle.getString("BUSCA_POR_CIDADE");
		long idServico = bundle.getLong("BUSCA_POR_SERVICOS");
		//Preenche Lista

		if (!cidade.equals("")){
			List<Estabelecimento> l = getListaEstabelecimentoPorCidade(cidade);
			ListaEstabelecimentoAdapter estabelecimentosAdapter = new ListaEstabelecimentoAdapter(this,  l);
			lv = (ListView) findViewById(R.id.listViewEstabelecimentos);
		    lv.setAdapter((ListAdapter) estabelecimentosAdapter);		
		}
			
		if (!(idServico==0L)){
			List<Estabelecimento> l = getListaEstabelecimentoPorServicos(idServico);
			ListaEstabelecimentoAdapter estabelecimentosAdapter = new ListaEstabelecimentoAdapter(this,  l);
			lv = (ListView) findViewById(R.id.listViewEstabelecimentos);
		    lv.setAdapter((ListAdapter) estabelecimentosAdapter);		
		}
		
		//Recebe o clique na lista estabelecimento e repassa o id do obj Estabelecimento para EstabelecimentoActivity
		lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

		    @SuppressWarnings("rawtypes")
			@Override
		    public void onItemClick(AdapterView adapter, View viw, int posicao,long id) {
			    Estabelecimento estabelecimento = (Estabelecimento) adapter.getItemAtPosition(posicao);
			    ArrayList<Estabelecimento> listaEstabelecimento = new ArrayList<Estabelecimento>();
			    listaEstabelecimento.add(estabelecimento);
			    
			    Intent it = new Intent(ListagemEstabelecimento.this, EstabelecimentoActivity.class);		 //getBaseContext()   
			    Bundle bundle = new Bundle(); 
			    bundle.putSerializable("lista_estabelecimento", (Serializable) listaEstabelecimento); 
			    it.putExtras(bundle); 
			    startActivity(it);
		    }            
		});

	}
	
	//M�todo que recebe a cidade e procura por estabelecimento desta e retorna em formato de Lista
	private List<Estabelecimento> getListaEstabelecimentoPorCidade(String cidade) {
        List<String> l = new ArrayList<String>();       
        EstabelecimentoList listaEstabelecimento = new EstabelecimentoList();
        listaEstabelecimento.setLista(new EstabelecimentoReq().getListaEstabelecimentoPorCidade(cidade).getLista());
       
        Toast.makeText(this, "Resultado!", Toast.LENGTH_SHORT).show();
        Log.i(CATEGORIA, "retorno Lista" + l.toString());
       
        return listaEstabelecimento.getLista();
    }
	
	//M�todo que recebe o ID de servicos e procura por estabelecimento desta e retorna em formato de Lista
	private List<Estabelecimento> getListaEstabelecimentoPorServicos(long idServico) {
        List<String> l = new ArrayList<String>();       
        EstabelecimentoList listaEstabelecimento = new EstabelecimentoList();
        listaEstabelecimento.setLista(new EstabelecimentoReq().getEstebelecimentoPorIdServico(idServico).getLista());
       
        Toast.makeText(this, "Resultado!", Toast.LENGTH_SHORT).show();
        Log.i(CATEGORIA, "retorno Lista" + l.toString());
       
        return listaEstabelecimento.getLista();
    }

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		
	}
}
