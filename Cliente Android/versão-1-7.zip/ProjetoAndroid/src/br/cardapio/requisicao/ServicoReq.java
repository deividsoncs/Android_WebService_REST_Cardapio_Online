package br.cardapio.requisicao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import br.cardapio.listas.ServicosList;

public class ServicoReq {
	
	
	//Lista Todos Servicos
	public ServicosList getListaServicos (){
		ServicosList servicosList  = new ServicosList();
		try{
	        URL url = new URL("http://localhost:8080/cardapio.online/rest/recursos/busca_todos_servicos");
	        HttpURLConnection con = (HttpURLConnection) url.openConnection();
	        if (con.getResponseCode() != 200)
	                throw new RuntimeException("HTTP error code : "+ con.getResponseCode());
	        BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));
	      //C�digo
	        
	        
	        con.disconnect();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
		return servicosList;
	}	
	
	public ServicosList getListaServicoPorIdEstabelecimento (long idEstabelecimento){
		ServicosList servicosList  = new ServicosList();
		try{
	        URL url = new URL("http://localhost:8080/cardapio.online/rest/recursos/busca_servicos/" + idEstabelecimento);
	        HttpURLConnection con = (HttpURLConnection) url.openConnection();
	        if (con.getResponseCode() != 200)
	                throw new RuntimeException("HTTP error code : "+ con.getResponseCode());
	        BufferedReader br = new BufferedReader(new InputStreamReader((con.getInputStream())));
	      
	        
	        
	        
	        //C�digo
	        con.disconnect();
	    } catch (IOException e) {
	        e.printStackTrace();
	    } 
		return servicosList;
	}	
}
