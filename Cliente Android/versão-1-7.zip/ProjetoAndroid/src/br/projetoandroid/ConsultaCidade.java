package br.projetoandroid;

import java.util.ArrayList;
import java.util.List;

import br.cardapio.bean.Estabelecimento;
import br.cardapio.listas.EstabelecimentoList;
import br.cardapio.requisicao.EstabelecimentoReq;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

public class ConsultaCidade extends MainActivity implements OnItemClickListener {

	private static final String CATEGORIA = "cardapio";
	private Spinner spinnerCidade;
	private List<String> listaCidades = new ArrayList<String>();
	private String cidade="", parametroConsulta="";
	private ListView lv;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.consulta_cidade);
		
		//Adicionando Nomes no ArrayList
		listaCidades.add("Cariacica");
		listaCidades.add("Vitoria");		
		listaCidades.add("Vila Velha");
		listaCidades.add("Serra");
		listaCidades.add("Guarapari");
		listaCidades.add("Viana");
		
		//Identifica o Spinner no layout
		spinnerCidade = (Spinner) findViewById(R.id.spinnerCidade);
		//Cria um ArrayAdapter usando um padr�o de layout da classe R do android, passando o ArrayList nomes
		ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, listaCidades);
		ArrayAdapter<String> spinnerArrayAdapter = arrayAdapter;
		spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
		spinnerCidade.setAdapter(spinnerArrayAdapter);
		
		//M�todo do Spinner para capturar o item selecionado
		spinnerCidade.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parent, View v, int posicao, long id) {
				//pega nome pela posi��o
				cidade = parent.getItemAtPosition(posicao).toString();	
				
			}
			@Override
			public void onNothingSelected(AdapterView<?> parent) {
 
			}
		});
		
		Button btListarEstabelecimentoCidade = (Button) findViewById(R.id.btListarEstabelecimentosCidade);
		btListarEstabelecimentoCidade.setOnClickListener(this); 
	}
	
	public void onClick(View v) {
		Intent it;
		switch (v.getId()){
		case R.id.btListarEstabelecimentosCidade:
			it = new Intent("LISTAGEM_ESTABELECIMENTO");
			parametroConsulta = cidade;
			
			it.putExtra("BUSCA_POR_CIDADE", parametroConsulta);
			startActivity(it);
		}
		
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		
	}
}
