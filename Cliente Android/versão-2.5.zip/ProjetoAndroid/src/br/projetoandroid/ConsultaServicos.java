package br.projetoandroid;

import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import br.cardapio.bean.Servicos;
import br.cardapio.requisicao.ServicoReq;

public class ConsultaServicos extends Activity implements OnItemClickListener{
	//private static final String CATEGORIA = "cardapio";
	private Spinner spinnerServicos;
	private long idServico=0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.consulta_servicos);
		
		List<Servicos> l = new ServicoReq().getListaServicos();

		spinnerServicos = (Spinner) findViewById(R.id.spinnerServicos);
		ArrayAdapter<Servicos> servicoAdapter = new ArrayAdapter<Servicos>(this, android.R.layout.simple_spinner_item, l);  
		spinnerServicos.setAdapter(servicoAdapter); 
		spinnerServicos.setPrompt("Selecione um servi�o");
		spinnerServicos.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parent, View v, int posicao, long id) {
				//pega nome pela posi��o			
				Servicos serv = (Servicos)parent.getSelectedItem();
				idServico = serv.getId();
				Log.i("ConsultaServico:", "idServico="+Long.toString(idServico));
			}
			@Override
			public void onNothingSelected(AdapterView<?> parent) {
 
			}
		});
	    
		getListenerButtonListaEstabelecimento();
	}
	
	public void getListenerButtonListaEstabelecimento(){
		Button btListarEstabelecimentoServico = (Button) findViewById(R.id.btListarEstabelecimentosServicos);
		btListarEstabelecimentoServico.setOnClickListener(new OnClickListener() { 
		@Override
		public void onClick(View v) {
			Intent it;
			switch (v.getId()){
			case R.id.btListarEstabelecimentosServicos:
				it = new Intent("LISTAGEM_ESTABELECIMENTO");
				//Seta o que ser� passado CIDADE e Reseta TODOS OUTROS!
				it.putExtra("BUSCA_POR_CIDADE", "");
				it.putExtra("BUSCA_POR_SERVICOS", idServico);
				startActivity(it);
			}		
		}
	});
	}
	

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		
	}
}
