package br.projetoandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MenuGeral extends MainActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		TextView view = new TextView(this);
		view.setText("Menu Geral");
		setContentView(R.layout.menu_geral);
		
		Button btConsultaCidade = (Button) findViewById(R.id.btConsultaCidade);
		btConsultaCidade.setOnClickListener(this);
		
		Button btConsultaServicos = (Button) findViewById(R.id.btConsultarServicos);
		btConsultaServicos.setOnClickListener(this);
	}
	
	public void onClick(View v) {
		Intent it;
		switch (v.getId()){
		case R.id.btConsultaCidade:
			it = new Intent("CONSULTA_CIDADE");
			startActivity(it);
			break;
		case R.id.btConsultarServicos:
			it = new Intent("CONSULTA_SERVICOS");
			startActivity(it);
			break;
		

		}
		
	}
}
