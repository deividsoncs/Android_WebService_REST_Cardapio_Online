package br.projetoandroid;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class ConsultaCidade extends MainActivity implements OnItemClickListener {
	private Spinner spinnerCidade;
	private List<String> listaCidades = new ArrayList<String>();
	private String cidade="";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.consulta_cidade);
		
		//Adicionando Nomes no ArrayList
		listaCidades.add("Cariacica");
		listaCidades.add("Vitoria");		
		listaCidades.add("Vila-Velha");
		listaCidades.add("Serra");
		listaCidades.add("Guarapari");
		listaCidades.add("Viana");
		
		//Identifica o Spinner no layout
		spinnerCidade = (Spinner) findViewById(R.id.spinnerCidade);
		//Cria um ArrayAdapter usando um padr�o de layout da classe R do android, passando o ArrayList nomes
		ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, listaCidades);
		ArrayAdapter<String> spinnerArrayAdapter = arrayAdapter;
		spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
		spinnerCidade.setAdapter(spinnerArrayAdapter);
		
		//M�todo do Spinner para capturar o item selecionado
		spinnerCidade.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parent, View v, int posicao, long id) {
				//pega nome pela posi��o
				cidade = parent.getItemAtPosition(posicao).toString();	
				
			}
			@Override
			public void onNothingSelected(AdapterView<?> parent) {
 
			}
		});
		
		Button btListarEstabelecimentoCidade = (Button) findViewById(R.id.btListarEstabelecimentosCidade);
		btListarEstabelecimentoCidade.setOnClickListener(this); 
	}
	
	public void onClick(View v) {
		Intent it;
		switch (v.getId()){
		case R.id.btListarEstabelecimentosCidade:
			it = new Intent(getApplicationContext(), ListagemEstabelecimento.class);
			//Seta o que ser� passado CIDADE e Reseta TODOS OUTROS!
			it.putExtra("BUSCA_POR_CIDADE", cidade);
			it.putExtra("BUSCA_POR_SERVICOS", 0);
			startActivity(it);
		}
		
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		
	}
}
