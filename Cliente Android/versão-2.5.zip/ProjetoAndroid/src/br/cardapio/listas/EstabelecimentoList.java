package br.cardapio.listas;

import java.util.ArrayList;
import java.util.List;

import br.cardapio.bean.Estabelecimento;

public class EstabelecimentoList {
	
    private List <Estabelecimento> lista =  null;

    public EstabelecimentoList(){
        lista = new ArrayList<Estabelecimento>();
    }

    public EstabelecimentoList(List<Estabelecimento> lista) {
		super();
		this.lista = lista;
	}
    

	public List<Estabelecimento> getLista() {
		return lista;
	}

	public void setLista(List<Estabelecimento> lista) {
		this.lista = lista;
	}

	public void add(Estabelecimento novo){
        lista.add(novo);
    }
    
    public boolean isEmpty(){
    	return lista.isEmpty();
    }
    
	public String toString() {
		String str = " ";
		for (Estabelecimento objeto : lista){
			str += objeto.toString() + " \n";
		}
		return str;
	}
}

