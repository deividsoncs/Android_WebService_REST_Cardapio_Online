package br.cardapio.listas;

import java.util.ArrayList;
import java.util.List;

import br.cardapio.bean.ItemCardapio;

public class ItemCardapioList {
	
    private List <ItemCardapio> lista =  null;

    public ItemCardapioList(){
        lista = new ArrayList<ItemCardapio>();
    }

    public void add(ItemCardapio novo){
        lista.add(novo);
    }
    
    public boolean isEmpty(){
    	return lista.isEmpty();
    }
    
	public String toString() {
		String str = " ";
		for (ItemCardapio objeto : lista){
			str += objeto.toString() + " \n";
		}
		return str;
	}

    public List<ItemCardapio> getLista() {
        return lista;
    }

    public void setLista(List<ItemCardapio> lista) {
        this.lista = lista;
    }
    
}