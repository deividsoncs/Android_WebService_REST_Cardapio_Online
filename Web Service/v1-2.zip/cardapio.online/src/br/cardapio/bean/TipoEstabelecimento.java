package br.cardapio.bean;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class TipoEstabelecimento {

	private long id;
	private long idEstabelecimento;
	private String tipoEstabelecimento;
	
	public TipoEstabelecimento() {
		super();
	}

	public TipoEstabelecimento(long idEstabelecimento,
			String tipoEstabelecimento) {
		super();
		this.idEstabelecimento = idEstabelecimento;
		this.tipoEstabelecimento = tipoEstabelecimento;
	}
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getIdEstabelecimento() {
		return idEstabelecimento;
	}
	public void setIdEstabelecimento(long idEstabelecimento) {
		this.idEstabelecimento = idEstabelecimento;
	}
	public String getTipoEstabelecimento() {
		return tipoEstabelecimento;
	}
	public void setTipoEstabelecimento(String tipoEstabelecimento) {
		this.tipoEstabelecimento = tipoEstabelecimento;
	}

	@Override
	public String toString() {
		return "TipoEstabelecimento [id=" + id + ", idEstabelecimento="
				+ idEstabelecimento + ", tipoEstabelecimento="
				+ tipoEstabelecimento + "]";
	}
	
	
	
}
