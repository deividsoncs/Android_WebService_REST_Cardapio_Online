package br.cardapio.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.cardapio.bean.Servicos;
import br.cardapio.recursos.Conexao;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class ServicosDAO {

	public ServicosDAO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public void adiciona(Servicos servico){

		String sql = "insert into servicos " + 
					"(id_estabelecimento, descricao)" + "values (?, ?)";
		
		try{
			Connection conn = (Connection) Conexao.getConexao();
			PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
			
			stmt.setLong(1, servico.getIdEstabelecimento());
			stmt.setString(2, servico.getDescricao());
			
			stmt.execute();
			stmt.close();
			conn.close();
		} catch (SQLException e){
			throw new RuntimeException (e);
		}
	}
	
	public List <Servicos> getLista() {
		try {
	         List <Servicos> listaServicos = new ArrayList <Servicos>();      
	         Connection conn = (Connection) Conexao.getConexao();
	         
	         PreparedStatement stmt = (PreparedStatement) conn.prepareStatement("select * from servicos");
	         ResultSet rs = stmt.executeQuery();
	 
	         while (rs.next()) {
	      
	        	 Servicos servico = new Servicos();
	        	 servico.setId(rs.getLong("id"));
	        	 servico.setIdEstabelecimento(rs.getLong("id_estabelecimento"));
	        	 servico.setDescricao(rs.getString("descricao"));
	        	
	        	 listaServicos.add(servico);
	         }
	         rs.close();
	         stmt.close();
	         conn.close();
	         return listaServicos;
	     } catch (SQLException e) {
	         throw new RuntimeException(e);
	     }
	}
	
	
	public void altera(Servicos servico) {
	     String sql = "update servicos set id_estabelecimento=?, descricao=?," +
	             "where id=?";
	     try {
	    	 Connection conn = (Connection) Conexao.getConexao();
	         PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
	         stmt.setLong(1, servico.getIdEstabelecimento());
	         stmt.setString(2, servico.getDescricao());
	         stmt.setLong(3, servico.getId());
	         
	         stmt.execute();
	         stmt.close();
	         conn.close();
	     } catch (SQLException e) {
	         throw new RuntimeException(e);
	     }
	 }

	
	 public void remove(Servicos servico) {
	     try {
	    	 Connection conn = (Connection) Conexao.getConexao();
	         PreparedStatement stmt = (PreparedStatement) conn.prepareStatement("delete" +
	                 "from servicos where id=?");
	         stmt.setLong(1, servico.getId());
	         stmt.execute();
	         stmt.close();
	         conn.close();
	     } catch (SQLException e) {
	         throw new RuntimeException(e);
	     }
	 }

}
