package webservice;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import classesBean.Estabelecimento;

import java.sql.Connection;
import java.util.List;

@Path("/recursos")
@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
public class Recursos {
	 //Acesso:
	 //http://localhost:8080/sistemas.distribuidos/rest/recursos/
	
	  @GET
	  public String sayPlainTextHello() {
		Connection connection = Conexao.getConexao();  
	    return "Hello Jersey";
	  }
	   
	  
	  @GET
	  @Path("/ESTAB")
	  public List <Estabelecimento> getEstabelecimento() { 
		  return new ArrayList <Estabelecimento> (bandasMap.values()); 
	  }
	  
	  
	  
	  
	  @PUT
	  @Path("/USUARIO/{loginUsuario}/{senhaUsuario}/{nomeUsuario}")
	  public void cadastrarUsuario(@PathParam("loginUsuario") String loginUsuario, @PathParam("senhaUsuario") String senhaUsuario,
			  @PathParam("nomeUsuario") String nomeUsuario){
		  
		  Usuario usuario = new Usuario(nomeUsuario, loginUsuario, senhaUsuario);
		  
		  //Cadastra usu�rio no banco!!!
		  
	  }
	  
	  @POST
	  @Path("/USUARIO/{loginUsuario}/{senhaUsuario}/{nomeUsuario}")
	  public void alterarUsuario(@PathParam("loginUsuario") String loginUsuario, @PathParam("senhaUsuario") String senhaUsuario, 
			  @PathParam("nomeUsuario") String nomeUsuario){
		  
		  Usuario usuario = new Usuario(nomeUsuario, loginUsuario, senhaUsuario);
		  
		  //Altera usu�rio no banco!!!
		  
	  }
	  
	  
	  @PUT
	  @Path("/USUARIO/{loginUsuario}/RECEITA/{nomeReceita}/{ingredientes}/{modoDePreparo}")
	  public void cadastrarReceita(@PathParam("loginUsuario") String loginUsuario, @PathParam("nomeReceita") String nomeReceita, 
			  @PathParam("ingredientes") String ingredientes/*Usar Json aqui!*/, @PathParam("modoPreparo") String modoPreparo){
	        
		  //Receita receita = new Receita(nomeReceita, ingredientes, loginUsuario);  acertar o construtor, fzer o marshaling de
		                                                                           //String para Lista, usar POJO Json.
		  
		  //Cadastrar Receita no Banco!!!
			  		
	  }
	  
	  
	  @POST
	  @Path("/USUARIO/{loginUsuario}/RECEITA/{nomeReceita}/{ingredientes}/{modoDePreparo}")
	  public void alterarReceita(@PathParam("loginUsuario") String loginUsuario, @PathParam("nomeReceita") String nomeReceita, 
			  @PathParam("ingredientes") String ingredientes/*Usar Json aqui!*/, @PathParam("modoPreparo") String modoPreparo){
	        
		  //Receita receita = new Receita(nomeReceita, ingredientes, loginUsuario);  acertar o construtor, fzer o marshaling de
          //String para Lista, usar POJO to Json.

		  
		  //Altera Receita no Banco!!!
			  		
	  }
	
	  
	  @POST
	  @Path("/USUARIO/{loginUsuario}/RECEITA")
	  public String listarReceitas (@PathParam("loginUsuario") String loginUsuario){
		  
		  //Consuta todas receitas no banco procurando pelo loginUsuario!!!
		  
		  String str="";
		  return str;
	  }
	  
	  @POST
	  @Path("/USUARIO/{loginUsuario}/RECEITA/{ingrediente}")
	  public String listarReceitasIngrediente(@PathParam("loginUsuario") String loginUsuario, @PathParam("ingrediente") String ingrediente){
		  
		  //Consultar receitas no banco, listando as receitas pelo ingrediente passado!
		  
		  String str = "";
		  return str;
	  }
	  
	  @POST
	  @Path("/USUARIO/{loginUsuario}/RECEITA/{ingrediente}/{loginUsuarioX}")
	  public String listarReceitasUsuarioX(@PathParam("loginUsuario") String loginUsuario, @PathParam("ingrediente") String ingrediente,
			  								@PathParam("loginUsuarioX") String loginUsuarioX){
		  
		  
		 //Lista Receitas do usu�rio (loginUsuarioX), passado! 
		  
		 String str = "";
		 return str;
	  }
	  
	  @DELETE
	  @Path("/USUARIO/{loginUsuario}/RECEITA/{idReceita}")
	  public String deletarReceita(@PathParam("loginUsuario") String loginUsuario, @PathParam("idReceita") int idReceita){
		  
		  //Deleta receita por ID.
		  
		  String str = "";
		  return str;
	  }
}
