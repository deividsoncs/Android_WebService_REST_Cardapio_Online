package classesBean;

public class SecaoCardapio {
 
	private int id;
	
	private int idCardapio;
	
	private String nomeSecaoCardapio;
	 
}
 
