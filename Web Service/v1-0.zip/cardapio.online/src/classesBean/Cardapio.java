package classesBean;

public class Cardapio {
 
	private int id;
	
	private int idEstabelecimento;
	 
	
	public void consultarCardapio() {
	 
	}
	 
	public void montarCardapio() {
	 
	}
	 
}
 
