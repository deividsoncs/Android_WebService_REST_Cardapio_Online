package classesBean;

public class Endereco {
	//Temos conhecimento que esta modelagem n�o � a mais adequeda, por�m, para fins de 
	//prot�tipo podemos prop�-la?
	
	private int id;
	
	private int idEstabelecimento;
	
	private int cep;
	 
	private int numero;
	 
	private String complemento;
	 
	private String logradouro;
	 
	private String estado;
	 
	private String cidade;	
	
	private String bairro;
	 
}
 
