package classesBean;

import java.awt.Image;
import java.util.List;

public class Estabelecimento {
	
	private int id;
	
	private int idUsuario;
 
	private String razaoSocial;
	 
	private String nomeFantasia;
	 
	private String telefone;
	 
	private String email;
	 
	private Image logotipo;
	 
	private Image foto;
	
	
	
	
	public List consultarCategoria() {
		return null;
	}
	 
	public List consultarServicos() {
		return null;
	}
	 
	public List consultarPromocionais() {
		return null;
	}
	 
	public List consultarEstabelecimentos() {
		return null;
	}
	 
}
 
