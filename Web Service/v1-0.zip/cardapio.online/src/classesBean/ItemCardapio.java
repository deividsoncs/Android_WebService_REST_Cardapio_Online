package classesBean;

public class ItemCardapio {
 
	private int id;
	
	private String nomeItem;
	 
	private Double pre�o;
	 
	private int idSecaoCardapio;
	 
	private int idPromocaoCardapio; //Ver como ficara a promo��o do item card�pio!
	 
	 
}
 
