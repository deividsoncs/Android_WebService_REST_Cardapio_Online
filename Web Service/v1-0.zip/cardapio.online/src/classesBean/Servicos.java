package classesBean;

public class Servicos {
 
	private int id;
	 
	private int idEstabelecimento;
	 
	private String descricao;
	 
}
 
