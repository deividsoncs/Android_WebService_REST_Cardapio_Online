package classesBean;
public class PromocaoCardapio {
 
	private int id;
	
	private String descricao;
	 
	private float desconto;
	 
	private int idItemCardapio;
	 
	
	public void listarPromocionais() {
	 
	}
	 
}
 
