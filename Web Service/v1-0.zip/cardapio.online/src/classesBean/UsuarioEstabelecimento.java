package classesBean;

public class UsuarioEstabelecimento{
 
	private int id;
	
	private String nome;
	 
	private String login;
	 
	private String senha;
	 
	
	
	public void obterCardapio() {
	 
	}
	 
}
 
