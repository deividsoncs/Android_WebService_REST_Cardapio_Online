package br.cardapio.listas;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import br.cardapio.bean.UsuarioEstabelecimento;

@XmlRootElement
public class UsuarioEstabelecimentoList {

    private List <UsuarioEstabelecimento> lista;

    public UsuarioEstabelecimentoList(){
        lista = new ArrayList<UsuarioEstabelecimento>();
    }

    public void add(UsuarioEstabelecimento novo){
        lista.add(novo);
    }
    
    public boolean isEmpty(){
    	return lista.isEmpty();
    }
}