package br.cardapio.bean;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Servicos {
 
	private long id;
	 
	private long idEstabelecimento;
	 
	private String descricao;

	public Servicos() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Servicos(long idEstabelecimento, String descricao) {
		super();
		this.idEstabelecimento = idEstabelecimento;
		this.descricao = descricao;
	}



	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getIdEstabelecimento() {
		return idEstabelecimento;
	}

	public void setIdEstabelecimento(long idEstabelecimento) {
		this.idEstabelecimento = idEstabelecimento;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	@Override
	public String toString() {
		return "Servicos [id=" + id + ", idEstabelecimento="
				+ idEstabelecimento + ", descricao=" + descricao + "]";
	}
	
	
	 
}
 
