package br.cardapio.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.cardapio.bean.Avaliacao;
import br.cardapio.recursos.Conexao;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class AvaliacaoDAO {

	public void adiciona(Avaliacao avaliacao){
		String sql = "insert into avaliacao " + 
				"(id_estabelecimento, relato, positivo)" + 
				"values (?, ?, ?)";
	
		try{
			Connection conn = (Connection) Conexao.getConexao();
			PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
			
			stmt.setLong(1, avaliacao.getIdEstabelecimento());
			stmt.setString(2, avaliacao.getRelato());
			stmt.setByte(3, avaliacao.getPositivo());
			
			stmt.execute();
			stmt.close();
			conn.close();
		} catch (SQLException e){
			throw new RuntimeException (e);
		}			
	}
	
	
	public void altera(Avaliacao avaliacao) {
	     String sql = "update avaliacao set id_estabelecimento=?, relato=?, positivo" +
	             "where id=?";
	     try {
	    	 Connection conn = (Connection) Conexao.getConexao();
	         PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
	         stmt.setLong(1, avaliacao.getIdEstabelecimento());
			 stmt.setString(2, avaliacao.getRelato());
			 stmt.setByte(3, avaliacao.getPositivo());
	         stmt.setLong(4, avaliacao.getId());
	         
	         stmt.execute();
	         stmt.close();
	         conn.close();
	     } catch (SQLException e) {
	         throw new RuntimeException(e);
	     }
	 }
	
	
	public List <Avaliacao> getLista() {
		try {
	         List <Avaliacao> listaAvaliacao= new ArrayList <Avaliacao>();      
	         Connection conn = (Connection) Conexao.getConexao();
	         
	         PreparedStatement stmt = (PreparedStatement) conn.prepareStatement("select * from avaliacao");
	         ResultSet rs = stmt.executeQuery();
	 
	         while (rs.next()) {
	      
	        	 Avaliacao avaliacao = new Avaliacao();
	        	 avaliacao.setId(rs.getLong("id"));
	        	 avaliacao.setIdEstabelecimento(rs.getLong("id_estabelecimento"));
	        	 avaliacao.setRelato(rs.getString("relato"));
	        	 avaliacao.setPositivo(rs.getByte("positivo"));
	        	 
	        	 listaAvaliacao.add(avaliacao);
	         }
	         rs.close();
	         stmt.close();
	         conn.close();
	         return listaAvaliacao;
	     } catch (SQLException e) {
	         throw new RuntimeException(e);
	     }
	}
	
	public void remove(Avaliacao avaliacao) {
	     try {
	    	 Connection conn = (Connection) Conexao.getConexao();
	         PreparedStatement stmt = (PreparedStatement) conn.prepareStatement("delete" +
	                 "from avaliacao where id=?");
	         stmt.setLong(1, avaliacao.getId());
	         stmt.execute();
	         stmt.close();
	         conn.close();
	     } catch (SQLException e) {
	         throw new RuntimeException(e);
	     }
	 }
}
