package br.cardapio.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.cardapio.bean.TipoEstabelecimento;
import br.cardapio.recursos.Conexao;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class TipoEstabelecimentoDAO {
	
	public void adiciona(TipoEstabelecimento tipoEstabelecimento){
		String sql = "insert into tipo_estabelecimento " + 
				"(id_estabelecimento, tipo_estabelecimento)" + 
				"values (?, ?)";
	
		try{
			Connection conn = (Connection) Conexao.getConexao();
			PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
			
			stmt.setLong(1, tipoEstabelecimento.getIdEstabelecimento());
			stmt.setString(2, tipoEstabelecimento.getTipoEstabelecimento());
			stmt.execute();
			stmt.close();
			conn.close();
		} catch (SQLException e){
			throw new RuntimeException (e);
		}			
	}
	
	
	public void altera(TipoEstabelecimento tipoEstabelecimento) {
	     String sql = "update tipo_estabelecimento set id_estabelecimento=?, tipo_estabelecimento=?" +
	             "where id=?";
	     try {
	    	 Connection conn = (Connection) Conexao.getConexao();
	         PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
	         stmt.setLong(1, tipoEstabelecimento.getIdEstabelecimento());
			 stmt.setString(2, tipoEstabelecimento.getTipoEstabelecimento());
	         stmt.setLong(3, tipoEstabelecimento.getId());
	         
	         stmt.execute();
	         stmt.close();
	         conn.close();
	     } catch (SQLException e) {
	         throw new RuntimeException(e);
	     }
	 }
	
	
	public List <TipoEstabelecimento> getLista() {
		try {
	         List <TipoEstabelecimento> listaTipoEstabelecimento= new ArrayList <TipoEstabelecimento>();      
	         Connection conn = (Connection) Conexao.getConexao();
	         
	         PreparedStatement stmt = (PreparedStatement) conn.prepareStatement("select * from tipo_estabelecimento");
	         ResultSet rs = stmt.executeQuery();
	 
	         while (rs.next()) {
	      
	        	 TipoEstabelecimento tipoEstabelecimento = new TipoEstabelecimento();
	        	 tipoEstabelecimento.setId(rs.getLong("id"));
	        	 tipoEstabelecimento.setIdEstabelecimento(rs.getLong("id_estabelecimento"));
	        	 tipoEstabelecimento.setTipoEstabelecimento(rs.getString("tipo_estabelecimento"));
	        	 
	        	 listaTipoEstabelecimento.add(tipoEstabelecimento);
	         }
	         rs.close();
	         stmt.close();
	         conn.close();
	         return listaTipoEstabelecimento;
	     } catch (SQLException e) {
	         throw new RuntimeException(e);
	     }
	}
	
	public void remove(TipoEstabelecimento tipoEstabelecimento) {
	     try {
	    	 Connection conn = (Connection) Conexao.getConexao();
	         PreparedStatement stmt = (PreparedStatement) conn.prepareStatement("delete" +
	                 "from tipo_estabelecimento where id=?");
	         stmt.setLong(1, tipoEstabelecimento.getId());
	         stmt.execute();
	         stmt.close();
	         conn.close();
	     } catch (SQLException e) {
	         throw new RuntimeException(e);
	     }
	 }
}
