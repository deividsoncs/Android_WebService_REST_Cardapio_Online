package br.cardapio.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import br.cardapio.bean.Cardapio;
import br.cardapio.recursos.Conexao;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class CardapioDAO {
	public void adiciona(Cardapio cardapio){
		String sql = "insert into cardapio " + 
				"(id_estabelecimento, data_modificacao)" + 
				"values (?, ?)";
	
		try{
			Connection conn = (Connection) Conexao.getConexao();
			PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
			
			stmt.setLong(1, cardapio.getIdEstabelecimento());
			stmt.setDate(2, cardapio.getDataModificacao());
			
			stmt.execute();
			stmt.close();
			conn.close();
		} catch (SQLException e){
			throw new RuntimeException (e);
		}			
	}
	
	
	public void altera(Cardapio cardapio) {
	     String sql = "update cardapio set id_estabelecimento=?, data_modificacao=?" +
	             "where id=?";
	     try {
	    	 Connection conn = (Connection) Conexao.getConexao();
	         PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
	         stmt.setLong(1, cardapio.getIdEstabelecimento());
			 stmt.setDate(2, cardapio.getDataModificacao());
	         stmt.setLong(3, cardapio.getId());
	         
	         stmt.execute();
	         stmt.close();
	         conn.close();
	     } catch (SQLException e) {
	         throw new RuntimeException(e);
	     }
	 }
	
	public void remove(Cardapio cardapio) {
	     try {
	    	 Connection conn = (Connection) Conexao.getConexao();
	         PreparedStatement stmt = (PreparedStatement) conn.prepareStatement("delete" +
	                 "from cardapio where id=?");
	         stmt.setLong(1, cardapio.getId());
	         stmt.execute();
	         stmt.close();
	         conn.close();
	     } catch (SQLException e) {
	         throw new RuntimeException(e);
	     }
	 }
	
	// Retorna o Card�pio referente a id do Estabelecimento Passado
	public Cardapio getCardapio(int id) {
		try {
	           
	         Connection conn = (Connection) Conexao.getConexao();
	         
	         PreparedStatement stmt = (PreparedStatement) conn.prepareStatement("SELECT cardapio.* "
	         		+ "FROM bd_cardapio.cardapio, bd_cardapio.estabelecimento "
	         		+ "WHERE cardapio.id_estabelecimento = estabelecimento.id = ?");
	         
	         stmt.setInt(1, id);
	         ResultSet rs = stmt.executeQuery();
	         Cardapio cardapio = new Cardapio();
	         
	         while (rs.next()) {
	        	 cardapio.setId(rs.getLong("id"));
	        	 cardapio.setIdEstabelecimento(rs.getLong("id_estabelecimento"));
	        	 cardapio.setDataModificacao(rs.getDate("data_modificacao"));
	         }
	         rs.close();
	         stmt.close();
	         conn.close();
	         return cardapio;
	     } catch (SQLException e) {
	         throw new RuntimeException(e);
	     }
	}  
}
