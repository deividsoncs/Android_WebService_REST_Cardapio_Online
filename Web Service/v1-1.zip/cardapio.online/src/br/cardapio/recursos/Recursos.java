package br.cardapio.recursos;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import br.cardapio.bean.Estabelecimento;
import br.cardapio.bean.UsuarioEstabelecimento;
import br.cardapio.dao.EstabelecimentoDAO;
import br.cardapio.dao.UsuarioEstabelecimentoDAO;

import java.util.ArrayList;
import java.util.List;

@Path("/recursos")
@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
public class Recursos {
	 
	  //Insere um novo usu�rio TESTE!!!
	  //Acesso: http://localhost:8080/cardapio.online/rest/recursos/novo_usuario
	  @GET
	  @Path("/novo_usuario")
	  @Produces(MediaType.TEXT_PLAIN)
	  public String sayPlainTextHello() {
		  UsuarioEstabelecimento usuario = new UsuarioEstabelecimento("Deividson", "calixt�o", "123456");
		  UsuarioEstabelecimentoDAO usuarioDao = new UsuarioEstabelecimentoDAO();
		  usuarioDao.adiciona(usuario);
		  
		  return "Gravou!";
	  }
	  
	  // Busca usu�rio pelo Nome deste
	  // Acesso: http://localhost:8080/cardapio.online/rest/recursos/busca_usuario/{nomeUsuario}
	  @GET
	  @Path("/busca_usuario/{nomeUsuario}")
	  @Produces({MediaType.TEXT_XML, MediaType.APPLICATION_XML})
	  public List <UsuarioEstabelecimento> getUsuario(@PathParam("nomeUsuario") String nomeUsuario){
		  List <UsuarioEstabelecimento> listaUsuario = new ArrayList <UsuarioEstabelecimento>(); 
		  
		  UsuarioEstabelecimento usuario = new UsuarioEstabelecimento();
		  UsuarioEstabelecimentoDAO usuarioDao = new UsuarioEstabelecimentoDAO();
		  
		  usuario.setNome(nomeUsuario);
		  listaUsuario = usuarioDao.getLista(usuario);
		  return listaUsuario;
	  }
	  
	  // Lista Todos Usu�rios
	  // Acesso: http://localhost:8080/cardapio.online/rest/recursos/lista_usuarios
	  @GET
	  @Path("/lista_usuarios")
	  @Produces({MediaType.TEXT_XML, MediaType.APPLICATION_XML})
	  public List <UsuarioEstabelecimento> getListaUsuarios(){
		  List <UsuarioEstabelecimento> listaUsuario = new ArrayList <UsuarioEstabelecimento>(); 
		  UsuarioEstabelecimentoDAO usuarioDao = new UsuarioEstabelecimentoDAO();
		  listaUsuario = usuarioDao.getLista();
		  return listaUsuario;
	  }
	
	  // Busca por estabelecimento, recebendo o ID deste como par�metro.
	  // Acesso: http://localhost:8080/cardapio.online/rest/recursos/busca_estabelecimento/{idEstabelecimento}
	  @GET
	  @Path("/busca_estabelecimento/{idEstabelecimento}")
	  @Produces({MediaType.TEXT_XML, MediaType.APPLICATION_XML})
	  public Estabelecimento getEstebelecimento(@PathParam("idEstabelecimento") int id){
		  //Estabelecimento estabelecimento = new Estabelecimento(); 
		  EstabelecimentoDAO estabelecimentoDao = new EstabelecimentoDAO();
		  return estabelecimentoDao.getEstabelecimentoPorId(id);
	  }
	  
}
