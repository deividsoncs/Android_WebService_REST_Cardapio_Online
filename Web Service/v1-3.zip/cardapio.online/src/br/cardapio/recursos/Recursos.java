package br.cardapio.recursos;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import br.cardapio.bean.Estabelecimento;
import br.cardapio.bean.UsuarioEstabelecimento;
import br.cardapio.business.EstabelecimentoBusiness;
import br.cardapio.business.UsuarioEstabelecimentoBusiness;

import java.util.List;

@Path("/recursos")
@Produces({MediaType.APPLICATION_XML, MediaType.TEXT_XML})
@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
public class Recursos {
	 
	  // ### USU�RIO ESTABELECIMENTO
	  //Insere um novo Usu�rio TESTE!!! 
	  //Acesso: http://localhost:8080/cardapio.online/rest/recursos/novo_usuario
	  @POST
	  @Path("/novo_usuario")
	  @Produces(MediaType.TEXT_PLAIN)
	  public String adicionaUsuarioEstabelecimento(UsuarioEstabelecimento usuario){
		  return new UsuarioEstabelecimentoBusiness().adiciona(usuario);
	  }
	  
	  //> Busca Usu�rios pelo Nome deste
	  // Acesso: http://localhost:8080/cardapio.online/rest/recursos/busca_usuario/{nomeUsuario}
	  @GET
	  @Path("/busca_usuario/{nomeUsuario}")
	  public List <UsuarioEstabelecimento> getUsuario(@PathParam("nomeUsuario") String nomeUsuario){
		  return new UsuarioEstabelecimentoBusiness().getUsuario(nomeUsuario);
	  }
	  
	  //> Lista Todos Usu�rios
	  // Acesso: http://localhost:8080/cardapio.online/rest/recursos/busca_todos_usuarios
	  @GET
	  @Path("/busca_todos_usuarios")
	  public List <UsuarioEstabelecimento> getListaTodosUsuarios(){
		  return new UsuarioEstabelecimentoBusiness().getListaTodosUsuarios();
	  }
	  
	  //### ESTABELECIMENTO:
	  //> Busca por Estabelecimento, recebendo o ID deste como par�metro.
	  // Acesso: http://localhost:8080/cardapio.online/rest/recursos/busca_estabelecimento_id/{idEstabelecimento}
	  @GET
	  @Path("/busca_estabelecimento_id/{idEstabelecimento}")
	  public Estabelecimento getEstebelecimento(@PathParam("idEstabelecimento") long id){
		  return new EstabelecimentoBusiness().getPorId(id);
	  }
	  
	  //> Busca por Todos Estabelecimentos no banco.
	  // Acesso: http://localhost:8080/cardapio.online/rest/recursos/busca_estabelecimento_todos
	  @GET
	  @Path("/busca_estabelecimento_todos")
	  public List <Estabelecimento> getListaTodosEstabelecimentos(){
		  return new EstabelecimentoBusiness().getListaTodos();
	  }
	  
	  //> Retornar a lista dos Estabelecimentos que tem algum ITEM de seu card�pio em PROMO��O
	  // Acesso: http://localhost:8080/cardapio.online/rest/recursos/busca_estabelecimento_promocao
	  @GET
	  @Path("/busca_estabelecimento_promocao")
	  public List <Estabelecimento> getListaEstabelecimentoPorPromocao(){
		  return new EstabelecimentoBusiness().getListaPorPromocao();
	  }
	  
	  //> Retornar a lista dos Estabelecimentos passando o Nome do Estabelecimento
	  // Acesso: http://localhost:8080/cardapio.online/rest/recursos/busca_estabelecimento_nome/{nomeEstabelecimento}
	  @GET
	  @Path("/busca_estabelecimento_nome/{nomeEstabelecimento}")
	  public List <Estabelecimento> getListaEstabelecimentoPorNome(@PathParam("nomeEstabelecimento") String nomeEstabelecimento){
		  return new EstabelecimentoBusiness().getListaPorNome(nomeEstabelecimento);
	  }
	  
	  //> Retornar a lista dos Estabelecimentos passando a Cidade. 
	  // Acesso: http://localhost:8080/cardapio.online/rest/recursos/busca_estabelecimento_cidade/{nomeCidade}
	  @GET
	  @Path("/busca_estabelecimento_cidade/{nomeCidade}")
	  public List <Estabelecimento> getListaEstabelecimentoPorCidade(@PathParam("nomeCidade") String nomeCidade){
		  return new EstabelecimentoBusiness().getListaPorCidades(nomeCidade);
	  }
	  
	  // Funcionando, POR�M, retornando em formato texto simples.
	  // Retornar a lista dos Estabelecimentos passando a ID do Servi�os selecionado, ex.: Todos estabelecimento que possuem "m�sica ao vivo"
	  // Acesso: http://localhost:8080/cardapio.online/rest/recursos/busca_estabelecimento_servico/{idServico}
	  @GET
	  @Path("/busca_estabelecimento_servico/{idServico}")
	  public List <Estabelecimento> getEstebelecimentoPorServico(@PathParam("idServico") long idServico){
		  return new EstabelecimentoBusiness().getListaPorServicos(idServico);
	  }
	  
	  // Funcionando, POR�M, retornando em formato texto simples.
	  // Lista todos Estabelecimentos pelos id do TipoEstabelecimento passado! Ex.: Lista de Estabelecimentos que s�o churrascarias.
	  // Acesso: http://localhost:8080/cardapio.online/rest/recursos/busca_estabelecimento_tipo/{idTipo}
	  @GET
	  @Path("/busca_estabelecimento_tipo/{idTipo}")
	  public List <Estabelecimento> getEstebelecimentoPorTipo(@PathParam("idTipo") long idTipo){
		  return new EstabelecimentoBusiness().getListaPorTipoEstabelecimento(idTipo);
	  }
}
